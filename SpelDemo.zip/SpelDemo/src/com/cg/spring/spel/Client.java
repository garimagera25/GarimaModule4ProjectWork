package com.cg.spring.spel;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
	ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
	City city=(City) context.getBean("city");
	System.out.println("city name:"+city.getName());
	System.out.println("State:"+city.getState());
	System.out.println("Population:"+city.getPopulation());
	
	DBConnection connection=(DBConnection) context.getBean("dbconnection");
	System.out.println("username:"+connection.getUsername());
	System.out.println("password:"+connection.getPassword());
	System.out.println("url:"+connection.getUrl());
	}
}
