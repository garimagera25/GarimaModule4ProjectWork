package com.cg.spring.spel;

public class City {
	private String name;
	private String state;
	private double population;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public double getPopulation() {
		return population;
	}
	public void setPopulation(double population) {
		this.population = population;
	}
	@Override
	public String toString() {
		return "City [name=" + name + ", state=" + state + ", population="
				+ population + "]";
	}
	
}
