package com.cg.service;

import java.util.List;

import com.cg.dao.ModuleDao;
import com.cg.dao.ModuleDaoImpl;
import com.cg.dto.Assessment;
import com.cg.dto.TraineeBean;
import com.cg.exception.ModuleScoreException;

public class ModuleServiceImpl implements ModuleService{
	ModuleDao mdao=new ModuleDaoImpl();
	
	@Override
	public List<TraineeBean> getTraineeId() throws ModuleScoreException {
		return mdao.getTraineeId();
	}

	@Override
	public long insertAssessment(Assessment assg) throws ModuleScoreException {
		return mdao.insertAssessment(assg);
	}

}
