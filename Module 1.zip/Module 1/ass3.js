var productArray=[["television","laptop","phone"],["soap","powder"]];
var pricePerQuantity=0;
function chooseCategory()
{
var category=productForm.category.value;
var productList = productForm.productList
if(category=='electronics')
 {
 for(i=0;i<productArray[0].length;i++)
 {
 var option = new Option();
 option.text = productArray[0][i];
 productList.options[i] = option;
 }
   } 
   else
   {
  for(i=0;i<productArray[1].length;i++)
  {
 var option = new Option();
 option.text=productArray[1][i];
 productList.options[i] = option;
    }
 }
 }
 function chooseProduct()
 {
 var productSelected=productForm.productList.value;

 if(productSelected=='television')
 {
 pricePerQuantity = 20000;
 }
 else if(productSelected=='laptop')
 {
 
 pricePerQuantity = 30000;
 }
 else if(productSelected=='phone')
 {
 pricePerQuantity = 10000;
 }
 else if(productSelected=='soap')
 {
 pricePerQuantity = 40;
 }
 if(productSelected=='powder')
 {
 pricePerQuantity =90;
 } 

 return pricePerQuantity;
 }
 function calculatePrice()
 {
 var quantity= productForm.quantity.value;
 var t = chooseProduct();
 
 var totalPrice= t*quantity;
 productForm.totalPrice.value = totalPrice;
 }