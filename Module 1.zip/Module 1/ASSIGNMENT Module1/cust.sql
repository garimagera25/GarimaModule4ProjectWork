Create Table Customer2(CustomerId number NOT NULL PRIMARY KEY, cust_name varchar2(20),Address1 Varchar2(30),Address2 Varchar2(30));

Alter table Customer2
modify cust_name varchar(30);

Alter table Customer2
ADD (Gender varchar(1),
 Age number(3), 
 PhoneNo number(10),
 Email varchar(30));
 
 Alter table Customer2
 drop column email;
 
 Create table AccountMaster1
 (AccountNumber number(10,2) PRIMARY KEY,
 customerId number(5) constraint Customer_Id_fk REFERENCES customer2(customerId),
 ACCOUNTTYPE varchar2(3),
 Ledgerbalance number(10,2)); 
 
 ALTER TABLE Accountmaster1 ADD CHECK(Accounttype='NRI' OR Accounttype='IND');
 
 ALTER TABLE Accountmaster1 ADD CONSTRAINTS BALANCE_CHK CHECK(Ledgerbalance>5000);
 
 
 CREATE SEQUENCE seq_Customer START WITH 1000
 INCREMENT BY 1;
 INSERT INTO customer1 VALUES(seq_Customer.NEXTVAL,'Smith','46,Lane 1','New York','M','35','7890893433');
 INSERT INTO customer1 VALUES(seq_Customer.NEXTVAL,'Jack','89,Lane 9','Washington','M','39','6690233433');
 INSERT INTO customer1 VALUES(seq_Customer.NEXTVAL,'Mary','78, Lane 5','Chicago','F','32','8990893433');
 INSERT INTO customer1 VALUES(seq_Customer.NEXTVAL,'Jack','46, Lane 8','New York','M','42','6690893123');
 
 CREATE SEQUENCE seq_master START WITH 2001
 INCREMENT BY 1;
 INSERT INTO Acc_master1 VALUES(seq_Customer.NEXTVAL,'2001','1003','Smith','NRI','5000');
 INSERT INTO Acc_master1 VALUES(seq_Customer.NEXTVAL,'2002','1001','Smith','IND','7000');
 INSERT INTO Acc_master1 VALUES(seq_Customer.NEXTVAL,'2003','1000','Smith','IND','9000');
 INSERT INTO Acc_master1 VALUES(seq_Customer.NEXTVAL,'2004','1002','Smith','NRI','4000');
 
 UPDATE TABLE Acc_master1
 SET Ledgerbalance='8000' where AccountNumber='2004';
 
 UPDATE TABLE Acc_master1
 SET Accounttype='IND' where AccountNumber='2004';
 
 DELETE FROM Acc_master1 where AccountNumber='2004';
 
 SELECT * FROM Acc_master1;
 
 SELECT * FROM Acc_master1 where ledgerbalance>5000;
 
 SELECT * FROM Acc_master1 where Accounttype='NRI';
 
 SELECT cust_name FROM customer1 where Address2='New Yorks';
 
 SELECT Cust_name,Ledgerbalance FROM customer1 c1 natural join Acc_master1 a1 where ACCOUNTTYPE='IND';
 OR
 SELECT Ledgerbalance FROM customer c1, Acc_master1 a1 where c1.customer_id=a1.customer_id AND Gender='M';
 SELECT Cust_name,Ledgerbalance FROM customer1 c1 natural join Acc_master1 a1 WHERE Gender='M';
 
 SELECT * FROM Acc_master1 c1 natural join customer1 a1 where age<40;