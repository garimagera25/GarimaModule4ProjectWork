function showData()
{ 
var title=t1.title.value;
var Firstname=t1.FirstName.value;
var Lastname=t1.LastName.value;
alert("all data for" +title+FirstName+LastName+"entered successfully"); 
}