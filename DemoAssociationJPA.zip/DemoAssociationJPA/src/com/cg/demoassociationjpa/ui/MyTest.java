package com.cg.demoassociationjpa.ui;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.demoassociationjpa.dto.User;
import com.cg.demoassociationjpa.dto.Vech;

public class MyTest {

	public static void main(String[] args) {
		
		EntityManagerFactory emFactory=Persistence.createEntityManagerFactory("DemoAssociationJPA");
		EntityManager em=emFactory.createEntityManager();
		Vech ve=new Vech();
		ve.setVechId(10);
		ve.setVechName("jeep");
		
		Vech ve2=new Vech();
		ve.setVechId(20);
		ve.setVechName("jeep");
		
		User u=new User();
		u.setUserId(1);
		u.setUserName("divya");
		//u.setV(ve); //FOR ONE TO ONE
		List<Vech> my=new ArrayList<>();
		my.add(ve);
		my.add(ve2);
		u.setV(my); //injecting vech into user
		
		em.getTransaction().begin();
		em.persist(u);
		em.persist(ve2);
		em.persist(ve);
		em.getTransaction().commit();
		em.close();
		emFactory.close();
	}
}
