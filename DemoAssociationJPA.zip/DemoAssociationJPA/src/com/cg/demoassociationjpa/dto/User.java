package com.cg.demoassociationjpa.dto;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="userdb")
public class User {
@Id
	private int userId;
	private String userName;
//	@OneToOne
//	Vech v;
//	public Vech getV(){
//		return v;
//	}
//	public void setV(Vech ve) {
//	this.v=v;
//	}

	@OneToMany
	List<Vech> v;
	
	
	public List<Vech> getV() {
		return v;
	}
	public void setV(List<Vech> v) {
		this.v = v;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + "]";
	}

	
	
}
