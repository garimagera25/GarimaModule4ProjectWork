package com.cg.demoassociationjpa.dto;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Vech {
@Id
	private int vechId;
	private String vechName;
	public int getVechId() {
		return vechId;
	}
	public void setVechId(int vechId) {
		this.vechId = vechId;
	}
	public String getVechName() {
		return vechName;
	}
	public void setVechName(String vechName) {
		this.vechName = vechName;
	}
	@Override
	public String toString() {
		return "Vech [vechId=" + vechId + ", vechName=" + vechName + "]";
	}
	
}
