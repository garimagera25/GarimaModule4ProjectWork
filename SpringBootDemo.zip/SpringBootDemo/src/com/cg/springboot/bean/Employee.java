package com.cg.springboot.bean;

import org.springframework.stereotype.Component;

@Component("emp")
public class Employee {

	public void printMessage(){
		System.out.println("Welcome to Spring Boot Application");
	}
}
