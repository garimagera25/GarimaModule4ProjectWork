package com.capgemini.xyz.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationServiceImpl implements ValidationService{

	@Override
	public boolean validateCustName(String name1) {
	
		Pattern pattern= Pattern.compile("[A-Z][a-z]{2,19}");
		Matcher matcher= pattern.matcher(name1);
		return matcher.matches();
	}
	
	@Override
	public boolean validateAddress(String name2) {
	
		Pattern pattern= Pattern.compile("[A-Z][a-z]{2,19}");
		Matcher matcher= pattern.matcher(name2);
		return matcher.matches();
	}
	
	@Override
	public boolean validateEmail(String mail) {
		Pattern pattern= Pattern.compile("[A-Za-z0-9]*@capgemini.com");
		Matcher matcher= pattern.matcher(mail);
		return matcher.matches();
	}

	@Override
	public boolean validateMobile(String mobno) {
		Pattern pattern= Pattern.compile("[0-9]{10}");
		Matcher matcher= pattern.matcher(mobno);
		return matcher.matches();
	}

}
