package com.capgemini.xyz.service;

public interface ValidationService {

	public boolean validateCustName(String name1);
	public boolean validateAddress(String name2);
	public boolean validateEmail(String mail);
	public boolean validateMobile(String mobno);
}
