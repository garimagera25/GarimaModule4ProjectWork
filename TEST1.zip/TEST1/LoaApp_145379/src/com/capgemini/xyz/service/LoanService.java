package com.capgemini.xyz.service;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.dao.ILoanDao;
import com.capgemini.xyz.dao.LoanDao;
import com.capgemini.xyz.exception.LoanException;

public class LoanService implements ILoanService {
	
	ILoanDao dao;
	public LoanService(){
			dao=new LoanDao();
	}
	public Long applyLoan(Loan loan) throws LoanException {
		return dao.applyLoan(loan);
		
	
	}
	
	public Customer validateCustomer(Customer customer)throws LoanException {
		return dao.validateCustomer(customer);

	}
	
	public long insertCust(Customer cust) throws LoanException {
		return dao.insertCust(cust);
		
	}
	
	public double calculateEMI(double amount,int duration) throws LoanException {
		return dao.calculateEMI(amount,duration);
		
	}
}
