package com.capgemini.xyz.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.exception.LoanException;
import com.capgemini.xyz.util.DatabaseConnection;

public class LoanDao implements ILoanDao{

	Connection connection;
	public LoanDao() {
		connection= DatabaseConnection.getConnection();
	}
	protected void finalize(){
		try {
			connection.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public long insertCust(Customer cust) throws LoanException{
		
		 String insQry=
					"INSERT INTO Customer_details (Cust_id,Cust_name,Address,Email,MobileNo) values (Customer_id_seq.nextval,?,?,?,?) ";
					try {
						PreparedStatement ps = connection.prepareStatement(insQry);
						
						Customer customer;
						ps.setString(1, cust.getCustName());
						ps.setString(2,cust.getAddress());
						ps.setString(3, cust.getEmail());
						ps.setString(4, cust.getMobile());
						
						int r= ps.executeUpdate();
						int Custid=0;
						if(r==1){
								Statement st= connection.createStatement();
								ResultSet rs= st.executeQuery("select Customer_id_seq.currval from dual");
								if(rs.next())
									Custid=rs.getInt(1);
						}
					return Custid;
					} catch (SQLException e) {
						throw new LoanException(e.getMessage());
					}
	}
	
	public long applyLoan(Loan loan) throws LoanException {
		
		  String insQry=
			"INSERT INTO Loan_details (Loan_id,Loan_amt,Cust_id ,Duration Number) values (Loan1_id_seq.nextval,?,?,?) ";
			try {
				PreparedStatement ps = connection.prepareStatement(insQry);
				
				ps.setDouble(1, loan.getLoanAmount());
				ps.setLong(2,loan.getCustId());
				ps.setInt(3, loan.getDuration());
				
				int r= ps.executeUpdate();
				int Loanid=0;
				if(r==1){
						Statement st= connection.createStatement();
						ResultSet rs= st.executeQuery("select Loan1_id_seq.currval from dual");
						if(rs.next())
							Loanid=rs.getInt(1);
				}
			return Loanid;
			} catch (SQLException e) {
				throw new LoanException(e.getMessage());
			}
	
}
	@Override
	public Customer validateCustomer(Customer customer) throws LoanException {
		
		return customer;
	}
	@Override
	public double calculateEMI(double amount, int duration) {
		double p=amount;
		int n=duration;
		n=n*12;
		double r=9.5;
		double emi=(p*r*(1+r)*n)/((1+r)*(n-1));
		return emi;
	}
}
