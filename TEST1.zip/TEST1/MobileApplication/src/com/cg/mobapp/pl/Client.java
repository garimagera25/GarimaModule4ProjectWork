package com.cg.mobapp.pl;

import java.util.List;
import java.util.Scanner;

import com.cg.mobapp.dto.Mobile;
import com.cg.mobapp.exception.MobileException;
import com.cg.mobapp.service.MobileService;
import com.cg.mobapp.service.MobileServiceImpl;

public class Client {

	public static void main(String[] args) {
		
		Mobile mobile= new Mobile();
		MobileService service=new MobileServiceImpl();
		Scanner sc= new Scanner(System.in);
		int option=0;
		do{
		System.out.println("1. Add Mobile Details ...");
		System.out.println("2. Display Mobile List ...");
		System.out.println("3. Display Mobile ...");
		System.out.println("4. Update Mobile Quantity ...");
		System.out.println("Enter choice. ");
		String name=sc.next();
		System.out.println("Enter Price :");
        double price=sc.nextDouble();
        System.out.println("Enter quantity");
        int quantity= sc.nextInt();
        
        mobile.setMobileName(name);
        mobile.setPrice(price);
        mobile.setQuantity(quantity);
        
        try {
        	int mobileid= service.addMobile(mobile);
        	System.out.println("Mobile added : "+ mobileid);
        } catch (MobileException e) {
        	System.out.println(e.getMessage());
        }
        break;
        //display all mobile details on console.
        case 2:
        try {
        List<Mobile> mobiles= service.getMobileList();
        if(mobiles.size()>0){
        for(Mobile mob :mobiles ){
        	System.out.println(mob.getMobileId()+" "+mob.getMobileName() );
        	System.out.println(" "+ mob.getPrice()+" "+mob.getQuantity());
        }
        }
        else
        	System.out.println("No mobile records available");
 } catch (MobileException e) {
	System.out.println(e.getMessage());
}
        break;
        //DISPLAY MOBILE DETAILS FOR SPECIFIC MOBILE ID
        case 3:
        System.out.println("Enter mobile no :");
        int mobileid=sc.nextInt();
        try {
        mobile =service.getMobileDetails(mobileid);
        
        System.out.println(mobile.getMobileId()+" "+ mobile.getMobileName()+" "+ mobile.getPrice() );
        
} catch (MobileException e) {
	System.out.println(e.getMessage());
}
        break;
        case 4:
        	System.out.println("Enter Quantity ");
        	int quan=sc.nextInt();
        	System.out.println("enter Mobile id ");
        	int mobid = sc.nextInt();
        	mobile.setMobileId(mobid);
        	mobile.setQuantity(quan);
        	
        	try {
        		int id=service.updateMobile(mobile);
        		if(id==1)
        			System.out.println("quantity updated successfully ");
        	} catch (MobileException e) {
        	break;
}//end of switch
}while(option!=4); //end of do while
}//end of main method

}//end of class