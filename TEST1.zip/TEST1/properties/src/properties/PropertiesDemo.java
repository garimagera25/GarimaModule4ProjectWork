package properties;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
public class PropertiesDemo {

	public static void main(String[] args) {
		 try{
			 InputStream file= new FileInputStream("./src/jdpc.properties");
			 Properties prop=  new Properties();
			 prop.load(file);
			 
			 String user= prop.getProperty("username");//IT WILL RETUEN THE VALUE OF USERNAME
			 String pwd= prop.getProperty("password");
			 String empid= prop.getProperty("empid");
			 String db=prop.getProperty("database");
			 
			 System.out.println("User : "+ user);
			 System.out.println("Password : "+ pwd);
			 System.out.println("ID : "+ empid);
			 System.out.println("database : "+ db);
			 
		 } catch (FileNotFoundException e){
			 System.out.println("File not found ");
		 } catch (IOException e){
			 e.printStackTrace();
		 }
	}
}
