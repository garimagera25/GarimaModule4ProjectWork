package com.cg.jdbc.demo;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.util.Properties;
import java.io.InputStream;

public class Assignment10 {
	
	public static void main(String[] args) {	
	try{
		InputStream file= new FileInputStream("./resources/PersonProps.properties");
		Properties prop= new Properties();
		prop.load(file);
		
		String name = prop.getProperty("name");
		String age= prop.getProperty("age");
		String gender= prop.getProperty("gender");
		String phoneNo= prop.getProperty("phoneNo");

		System.out.println("name : "+ name);
		System.out.println("age : "+ age);
		System.out.println("gender : "+ gender);
		System.out.println("phoneNo : "+ phoneNo);
		 
	 } catch (FileNotFoundException e){
		 System.out.println("File not found ");
	 } catch (IOException e){
		 e.printStackTrace();
	 }
}
}
