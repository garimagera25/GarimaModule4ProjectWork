package com.cg.jdbc.demo;
import java.util.*;
import java.io.*;


public class Assignment101 {
public static void main(String[] args) throws Exception {
	 

	Properties p= new Properties();
    p.setProperty("name", "varnika12");
    p.setProperty("age", "22yr");
    p.setProperty("gender", "female");
    p.setProperty("phoneNo", "8965898766");

    p.store(new FileWriter("PersonProps.properties"),null);
}
}
