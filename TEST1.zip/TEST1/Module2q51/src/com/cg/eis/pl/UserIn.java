package com.cg.eis.pl;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;


public class UserIn {
public static void main(String[] args) {
	EmployeeService es=new Employee(102,"varnika",40000,"Manager");
	es.insuranceScheme(40000, "Manager");
	es.display();
}
}
