package com.cg.eis.bean;
import com.cg.eis.service.EmployeeService;

public class Employee<insuranceScheme> implements EmployeeService {
int id;
String name;
double salary;
String designation;
String insuranceScheme;
public Employee(int id,String name,double salary,String designation)
{
	this.id=id;
	this.name=name;
	this.salary=salary;
	this.designation=designation;
}
public void display()
{
	System.out.println("Name="+this.name);
	System.out.println("Id="+this.id);
	System.out.println("Salary="+this.salary);
	System.out.println("Designation="+this.designation);
}
public void insuranceScheme(double salary,String designation)
{
	salary=this.salary;
	designation=this.designation;
	if((salary>5000 && salary<20000) && designation=="System Associate")
	{
		this.insuranceScheme="Scheme C";
		System.out.println("insurance scheme is:"+this.insuranceScheme);
	}
	if((salary>=20000 && salary<40000) && designation=="Programmer")
	{
		this.insuranceScheme="scheme B";
		System.out.println("insurance scheme is:"+this.insuranceScheme);
	}
	if((salary>=40000) && designation=="Manager")
	{
		this.insuranceScheme="scheme A";
		System.out.println("insurance scheme is:"+this.insuranceScheme);
	}
	if((salary<5000) && designation=="Clerk")
	{
		this.insuranceScheme="No scheme ";
		System.out.println("insurance scheme is:"+this.insuranceScheme);
	}
	else
		this.insuranceScheme="invalid";
}
}
