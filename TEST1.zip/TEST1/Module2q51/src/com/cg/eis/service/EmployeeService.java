package com.cg.eis.service;

public interface EmployeeService {
public void insuranceScheme(double salary,String designation);
public void display();
}
