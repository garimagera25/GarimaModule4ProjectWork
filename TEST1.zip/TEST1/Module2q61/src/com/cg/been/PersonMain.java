package com.cg.been;

public class PersonMain {
public static void main(String[] args) {
	System.out.println("Person Details");
	Person per=new Person("nikhil","Kumar",'M');
	per.ValidateFullname("nikhil");
	per.printpersondetails();
}
}
