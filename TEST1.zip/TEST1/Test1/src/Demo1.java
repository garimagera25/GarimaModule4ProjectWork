
//class A{
//	String name;
//	A(){
//		
//	}
//	A(String name){
//		this.name=name;
//	}
//}
//class B extends A{
//	B(){
//	}
//	B(String name,int number){
//		super(name);
//		this(number);
//	}
//	B(int number){
//		number=23;
//	}
//}
public class Demo1 {
public static void divide(float num1,float num2){
	try{
	float res=num1/num2;
	System.out.println("result :"+res);
	}catch(RuntimeException e){
		System.out.println("in catch");
	}
	finally{
		System.out.println("in finally");
	}
}
public static void main(String[] args) {
	divide(23,0);
}
}
