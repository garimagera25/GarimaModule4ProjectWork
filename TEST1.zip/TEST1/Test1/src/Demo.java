import java.util.Scanner;


public class Demo {
public static void main(String[] args) {
	String str="a,an,the should be used at appropriate places";
	Scanner scanner =new Scanner(str);
	scanner.useDelimiter(",");
	
	while(scanner.hasNext()){
		System.out.println(scanner.next());
	}
}
}
