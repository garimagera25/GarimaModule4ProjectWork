
public class Student {
static int num;
public static void  print(){
	System.out.println(num);
}
public static void main(String[] args) {
//	Student s1=new Student();
//	s1.print();
	String str1="Hello";
	String str2="Hello";
	if(str1.equals(str2))
	{
		System.out.println("both are equal");
	}
		else
			System.out.println("both are not equal");
	}
}
