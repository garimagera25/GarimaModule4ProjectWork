import java.util.stream.Stream;


public class BasicStreamDemo {

	public static void main(String[] args) {
				Stream<Integer> stream= Stream.of(34,74,63,843,73,435,62,254);
	//1	stream.forEach( (num) -> System.out.println(num));
				
				stream.map((num)->{ if(num%2==0) return "Even";
				else 
					return "Odd";}).forEach((str)->System.out.println(str));
				
				
				//3 long evenNumbers=stream.map((num)->{ if(num%2==0) return "Even";
				//else 
					//return "Odd";}).filter((str)->str.equalsIgnoreCase("Even")).count();
				//System.out.println(evenNumbers);
				
				//4stream.filter((num)->num%2==0).forEach((num)->System.out.println(num));
				}
	//5Stream<Integer> uniqueEles=stream.distinct();
	//uniqueEles.forEach(System.out::println);
	
	//6int result=stream.reduce((num1,num2)->{ if(num1>num2 )return num1;
	                                    //  else return num2;}).get();
	//System.out.println(result);
}

