


public class HelloThread1 implements Runnable{

	public String name;
	public HelloThread1(String name) {
		this.name=name;
	}
	
	
	
	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	@Override
	public void run() {
		
		System.out.println("in run method : "+this.getName());
		for(int i=1;i<=5;i++){
			try {
				Thread.sleep(2000);
				System.out.println(this.getName()+ " : " + i);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println(this.getName()+ " will die now.");
	}
	 public static void main(String[] args) {
		HelloThread t1=new HelloThread("Tom");
		HelloThread t2=new HelloThread("Jerry");
		
		Thread th1=new Thread(t1);
		Thread th2=new Thread(t2);
		
		th2.setPriority(10);
		th1.start();
		th2.start();
		
		try {
			th2.join();
		} catch (InterruptedException e1) {
			
			e1.printStackTrace();
		}
		
		for(int i=1;i<=10;i++){
			try {
				Thread.sleep(2000);
				System.out.println("in main Thread : "+i);
			} catch (InterruptedException e){
				e.printStackTrace();
			}
		}
		System.out.println("is Tom alive : "+ th1.isAlive());
		System.out.println("is Jerry alive : "+ th2.isAlive());
	}
}
