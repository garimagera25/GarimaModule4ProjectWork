
public class HelloThread extends Thread{

	public HelloThread(String name) {
		super(name);
	}
	@Override
	public void run() {
		
		System.out.println("in run method : "+this.getName());
		for(int i=1;i<=5;i++){
			try {
				Thread.sleep(2000);
				System.out.println(this.getName()+ " : " + i);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println(this.getName()+ " will die now.");
	}
	 public static void main(String[] args) {
		HelloThread th1=new HelloThread("Tom");
		HelloThread th2=new HelloThread("Jerry");
		
		th1.start();
		th2.start();
		
		for(int i=1;i<=10;i++){
			try {
				Thread.sleep(2000);
				System.out.println("in main Thread : "+i);
			} catch (InterruptedException e){
				e.printStackTrace();
			}
		}
		System.out.println("is Tom alive : "+ th1.isAlive());
		System.out.println("is Jerry alive : "+ th2.isAlive());
	}
}
