package com.cg.unit.testing;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import junit.framework.Assert;

		public class TestCalculator {
			
		
		static Calculator calc;
		
		@BeforeClass
		public static void createObject()
		{
			System.out.println("in create object method");
			calc= new Calculator();
		}
		
		@AfterClass
		public static void cleanup()
		{
			System.out.println("clean up");
		}
		
		@Test
		public void testAdd(){
		//Calculator calc=new Calculator();
		int res= calc.add(3, 8);
		System.out.println("in test add() ");
		Assert.assertEquals(11,res);
	}
		@Test
		public void testSubtract(){
			System.out.println("in test subtract() ");
		//Calculator calc=new Calculator();
		int res= calc.subtract(14, 5);
		Assert.assertEquals(9,res);
		}
		
		@Test
		public void testGetMax(){
			//Calculator calc=new Calculator();
			int max= calc.getmax(23, 63);
			Assert.assertEquals(63,max);
		}
	}

