package com.cg.unit.testing;

import org.junit.BeforeClass;
import org.junit.Test;

import junit.framework.Assert;

public class TestCalculator2 {

  static Calculator calc;
  
  @BeforeClass
  public static void create()
  {
	  System.out.println("in create object method");
	  calc=new Calculator();
  }
  
  @Test
  public void testmutiply()
  {
	  int res= calc.add(3, 8);
	  System.out.println("in test mutiply()");
	  Assert.assertEquals(24,res);
  }
  
  @Test
  public void testgetMin()
  {
	  int min= calc.add(3, 8);
	  Assert.assertEquals(3,min);
  }
  
  
}
