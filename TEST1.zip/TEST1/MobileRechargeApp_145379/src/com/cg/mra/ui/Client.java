package com.cg.mra.ui;

import java.util.Scanner;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.cg.account.exception.AccountException;
import com.cg.mra.beans.Account;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;


public class Client {

	public static void main(String[] args) {
		PropertyConfigurator.configure("Resources/log4j.properties");
	Account account= new Account();
	AccountService service= new AccountServiceImpl();
	Logger logger=Logger.getLogger(Client.class);
	Scanner sc = new Scanner(System.in);
	int option=0;
	
	do{
    System.out.println("\n\n1.Display Account Balance...");
	System.out.println("2. Recharge Account ...");
	System.out.println("3. Exit");
	System.out.println("Enter Choice .");
	option= sc.nextInt();
	switch(option){
	case 1:
		
		System.out.println("Enter Account ID : ");
		String accId =sc.next();
		try {
			account=service.getAccountDetails(accId);
			
			System.out.println("Your AccountId" +account.getAccountId()+" is having AccountBalance" +account.getAccountBalance());
			logger.info("Your AccountId" +account.getAccountId()+" is having AccountBalance" +account.getAccountBalance());
		} catch (AccountException e) {
			System.out.println(e.getMessage());
			logger.error(e.getMessage());
		}break;
		
		
	case 2:
		System.out.println("Enter recharge amount");
		logger.info("Enter recharge amount");
		double recharge=sc.nextDouble();
		System.out.println("Enter accountId  ");
		logger.info("Enter accountId ");
		String aid=sc.next();
		account.setAccountBalance(recharge);
		account.setAccountId(aid);
		
		try {
			int rev= service.rechargeAccount(aid, recharge);
			if(rev==1){
				System.out.println("recharge updated successfully ");
			    logger.info("recharge updated successfully");
		}
			else
				System.out.println("failed");
			    logger.info("failed");
		} 
		catch (AccountException e) {
			System.out.println(e.getMessage());
			logger.error(e.getMessage());
		}
		
		break;
		
	case 3:  break;
	default:System.out.println("wrong choice");
	  logger.info("wrong choice");
	
	}//end of switch
 }while(option!=4);
	}
	
	}
