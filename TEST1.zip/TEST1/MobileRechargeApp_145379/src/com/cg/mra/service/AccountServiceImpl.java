package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.account.exception.AccountException;

public class AccountServiceImpl implements AccountService {
	AccountDao dao;
	
	public AccountServiceImpl(){
		dao= new AccountDaoImpl();
	}
	
@Override
public	Account getAccountDetails(String accountId) throws AccountException {
	return dao.getAccountDetails(accountId);
}

@Override
public int rechargeAccount(String accountId, double rechargeAmount) throws AccountException{
	return dao.rechargeAccount(accountId,rechargeAmount);
}

}
