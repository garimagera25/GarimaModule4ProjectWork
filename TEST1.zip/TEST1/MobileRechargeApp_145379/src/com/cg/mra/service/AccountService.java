package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.account.exception.AccountException;

public interface AccountService {


	Account getAccountDetails(String accountId) throws AccountException;
	int rechargeAccount(String accountId, double rechargeAmount) throws AccountException;
}
