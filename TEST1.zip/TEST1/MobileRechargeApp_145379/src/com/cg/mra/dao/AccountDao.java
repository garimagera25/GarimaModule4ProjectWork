package com.cg.mra.dao;

import com.cg.account.exception.AccountException;
import com.cg.mra.beans.Account;

public interface AccountDao {

	Account getAccountDetails(String accountId) throws AccountException;

	int rechargeAccount(String accountId, double rechargeAmount) throws AccountException;
}
