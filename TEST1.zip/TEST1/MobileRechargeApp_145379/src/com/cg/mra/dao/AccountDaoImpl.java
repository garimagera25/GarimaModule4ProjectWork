package com.cg.mra.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.cg.account.exception.AccountException;
import com.cg.mra.beans.Account;
import com.cg.mra.util.DatabaseConnection;

public class AccountDaoImpl implements AccountDao{
	
	Connection connection;
	public AccountDaoImpl() {
		connection= DatabaseConnection.getConnection();
	}
	protected void finalize(){
		try {
			connection.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}

	@Override
	 public Account getAccountDetails(String accountId) throws AccountException {
	Account account= new Account();
   String selQry="SELECT ACCOUNT_ID ,ACC_BALANCE FROM ACCOUNT where ACCOUNT_ID=?";
	
	try {
		PreparedStatement ps= connection.prepareStatement(selQry);
		ps.setString(1, accountId);
		ResultSet rs = ps.executeQuery();
		if(rs.next()){
				account.setAccountId(rs.getString(1));
				account.setAccountBalance(rs.getDouble(2));
		}
		else 
		throw new AccountException("Account Id Does Not Exists");
		
	} catch (SQLException e) {
		throw new AccountException(e.getMessage());
	}
	return account;
	}
	
	@Override
	public int rechargeAccount(String accountId, double rechargeAmount) throws AccountException {
		String a=accountId;
		double r=rechargeAmount;
	   String updateQry="update Account set ACC_BALANCE=? where ACCOUNT_ID=? ";
	   try {
		   PreparedStatement ps= connection.prepareStatement(updateQry);
		   ps.setDouble(1, r);
		   ps.setString(2, a);
		   int rs=ps.executeUpdate();
		   return rs;
	   } catch (SQLException e) {
		   throw new AccountException(e.getMessage());
	   }
	}
}
