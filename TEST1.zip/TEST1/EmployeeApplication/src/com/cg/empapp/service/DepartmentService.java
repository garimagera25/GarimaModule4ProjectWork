package com.cg.empapp.service;

	import com.cg.empapp.dto.Department;
	import com.cg.empapp.exception.EmployeeException;

	public interface DepartmentService {
		
		
		int addDepartment(Department department)throws EmployeeException;
		
}
