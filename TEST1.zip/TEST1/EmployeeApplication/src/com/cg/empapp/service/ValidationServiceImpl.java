package com.cg.empapp.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationServiceImpl implements ValidationService {

	@Override
	public boolean validateFname(String name1) {
		Pattern pattern= Pattern.compile("[A-Z][a-z]{2,19}");
		Matcher matcher= pattern.matcher(name1);
		return matcher.matches();
	}

	@Override
	public boolean validateLname(String name2) {
		Pattern pattern= Pattern.compile("[A-Z][a-z]{2,19}");
		Matcher matcher= pattern.matcher(name2);
		return matcher.matches();
	}

	@Override
	public boolean validateSalary(double salary) {
		
		return false;
	}

	@Override
	public boolean validateMobile_No(String mid) {
		Pattern pattern= Pattern.compile("[0-9]{10}");
		Matcher matcher= pattern.matcher(mid);
		return matcher.matches();
	}
}
