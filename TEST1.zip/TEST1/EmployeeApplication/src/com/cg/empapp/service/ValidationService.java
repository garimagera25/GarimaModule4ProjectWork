package com.cg.empapp.service;

public interface ValidationService {

	boolean validateFname(String name1);
    boolean validateLname(String name2);
	boolean validateSalary(double salary);
	boolean validateMobile_No(String mid);
		
}
