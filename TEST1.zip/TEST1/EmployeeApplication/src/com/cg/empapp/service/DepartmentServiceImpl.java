package com.cg.empapp.service;

import com.cg.empapp.dao.DepartmentDaoImpl;
import com.cg.empapp.dto.Department;
import com.cg.empapp.exception.EmployeeException;

	public class DepartmentServiceImpl implements DepartmentService{

		DepartmentDaoImpl dao;
		public DepartmentServiceImpl() {
			dao= new DepartmentDaoImpl();
		
		}
		@Override
		public int addDepartment(Department department)
				throws EmployeeException {
			return dao.addDepartment(department);
		}

}
