package com.cg.empapp.dao;

import java.util.List;

import com.cg.empapp.dto.Employee;
import com.cg.empapp.exception.EmployeeException;

public interface EmployeeDao {
		
		public int addEmployee(Employee employee)throws EmployeeException;
		public Employee getEmployeeDetails(int id) throws EmployeeException;
		public int updateEmployee(Employee emp) throws EmployeeException;
		public int deleteEmployee(int id) throws EmployeeException;
		public List<Employee> getEmployeeList() throws EmployeeException;
		
		
}
