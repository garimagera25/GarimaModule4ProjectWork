package com.cg.empapp.dao;

import com.cg.empapp.dto.Department;
import com.cg.empapp.dto.Employee;
import com.cg.empapp.exception.EmployeeException;
import com.cg.empapp.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;


	public class  DepartmentDaoImpl implements  DepartmentDao {

		Connection connection ;
		public  DepartmentDaoImpl() {
			connection= DatabaseConnection.getConnection();
		
		}
		
		public int addDepartment(Department department)
				throws EmployeeException {
			
			String insQry= "insert into department(dept_id,dept_name) " 
			+" values(?,?) ";
			int dept_id=0;
			try {
				PreparedStatement ps= connection.prepareStatement(insQry);
				ps.setInt(1,Department.getDept_id());
				ps.setString(2,Department.getDept_name());
			
				int r= ps.executeUpdate();
				if(r==1){
						Statement st= connection.createStatement();
						ResultSet rs= st.executeQuery("select dept_id_seq.currval from dual");
						if(rs.next())
							dept_id= rs.getInt(1);
				}
			} catch (SQLException e) {
				throw new EmployeeException(e.getMessage());
			}
			return dept_id;
		}

		@Override
		public List<Employee> getEmployeeList() throws EmployeeException {
			// TODO Auto-generated method stub
			return null;
		}		

	}
