package com.cg.empapp.dao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.empapp.dto.Employee;
import com.cg.empapp.util.DatabaseConnection;
import com.cg.empapp.exception.EmployeeException;

	public class EmployeeDaoImpl implements EmployeeDao {

		Connection connection ;
		public EmployeeDaoImpl() {
			connection= DatabaseConnection.getConnection();
		
		}
		
		public int addEmployee(Employee employee) throws EmployeeException {
			
			String insQry= "insert into employees (employee_id, fname,lname,gender,salary,joindate,age,designation,mobile_no,dept_id) "
			+" values (employee_id_seq.nextval,?,?,?,?,?,?,?,?,?)"; 
			try {
				PreparedStatement ps= connection.prepareStatement(insQry);
				
				ps.setString(1,Employee.getFname());
				ps.setString(2,Employee.getLname());
				ps.setString(3,Employee.getGender());
				ps.setDouble(4,Employee.getSalary());
				Date date=Date.valueOf(Employee.getJoindate());
				ps.setDate(5, date);
				ps.setInt(6,Employee.getAge());
				ps.setString(7, Employee.getDesignation());
				ps.setString(8,Employee.getMobile_no());
				ps.setInt(9, Employee.getDeptid());
			
				int r= ps.executeUpdate();
				int empid=0;
				if(r==1){
						Statement st= connection.createStatement();
						ResultSet rs= st.executeQuery("select employee_id_seq.currval from dual");
						if(rs.next())
							empid= rs.getInt(1);
				}
				return empid;
			} catch (SQLException e) {
				throw new EmployeeException(e.getMessage());
			}
		}

		@Override
		public int updateEmployee(Employee employee) throws EmployeeException {
			
			String updateQry= "update employees set salary=? where employee_id=?";
			try {
				PreparedStatement ps= connection.prepareStatement(updateQry);
				ps.setDouble(1, Employee.getSalary());
				ps.setInt(2, Employee.getEmployee_id());
				int rs= ps.executeUpdate();
				return rs;
			} catch (SQLException e) {
				throw new EmployeeException(e.getMessage());
			}
		}

		@Override
		public Employee getEmployeeDetails(int id) throws EmployeeException {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public int deleteEmployee(int id) throws EmployeeException {
			String deleteQry= "delete from  employees where employee_id=?";
			try {
				PreparedStatement ps= connection.prepareStatement(deleteQry);
				ps.setInt(1, id);
				int rs= ps.executeUpdate();
				return rs;
			} catch (SQLException e) {
				throw new EmployeeException(e.getMessage());
			}
		}
		@Override
		public List<Employee> getEmployeeList() throws EmployeeException {
			// TODO Auto-generated method stub
			return null;
		}

	}
