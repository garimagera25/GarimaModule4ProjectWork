package com.cg.empapp.dao;

	import java.util.List;

import com.cg.empapp.dto.Department;
import com.cg.empapp.dto.Employee;
import com.cg.empapp.exception.EmployeeException;

	public interface DepartmentDao {
		
		
		int addDepartment(Department department)throws EmployeeException;
		public List<Employee> getEmployeeList() throws EmployeeException;
	}

