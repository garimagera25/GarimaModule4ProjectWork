package com.cg.empapp.pl;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.cg.empapp.dto.Employee;
import com.cg.empapp.dto.Department;
import com.cg.empapp.exception.EmployeeException;
import com.cg.empapp.service.EmployeeService;
import com.cg.empapp.service.EmployeeServiceImpl;
import com.cg.empapp.service.ValidationService;
import com.cg.empapp.service.ValidationServiceImpl;

public class Client {
	
	public static void main(String[] args) {
		
		
		Employee employee= new Employee();
		EmployeeService service= new EmployeeServiceImpl();
		Department department= new Department();
		ValidationService validation=new ValidationServiceImpl();
		Scanner sc= new Scanner(System.in);
		int option=0;
		do{
	    System.out.println("\n\n1. Display Employee Details ...");
		//System.out.println("2. Display Employee List ...");
	    System.out.println("2. Update Employee Salary ");
	    //System.out.println("4. Delete Employee ");
		//System.out.println("5. Add Employee Details ");
		//System.out.println("6. Exit");
		System.out.println("Enter Choice .");
		 option= sc.nextInt();
		
		int employee_id;
		switch(option){
		case 1 :
		
		do{
			System.out.println("Enter fname : ");
			String name1 =sc.next();
			boolean res=validation.validateFname(name1);
			if(res==true)
			{
				employee.setFname(name1);
				break;
			}
			else
				System.out.println("Name should contain only alphabets");
			}while(true);
		
		do{
			System.out.println("Enter Lname : ");
			String name2 =sc.next();
			boolean res=validation.validateLname(name2);
			if(res==true)
			{
				employee.setLname(name2);
				break;
			}
			else
				System.out.println("Name should contain only alphabets");
			}while(true);
	

			  System.out.println("Enter Salary : ");
			  double Salary= sc.nextDouble();
					employee.setSalary(Salary);
					
		  System.out.println("Enter  Age: ");
		  int age= sc.nextInt();
		  employee.setAge(age);
		  
		  System.out.println("Enter designation : ");
		  String dsg =sc.next();
		  employee.setDesignation(dsg);
		  
		  System.out.println("Enter gender : ");
		  String gen =sc.next();
		  employee.setGender(gen);
		  
		  System.out.println("Enter deptid : ");
		  Integer depid =sc.nextInt();
		  employee.setDeptid(depid);
		  
		  do{
		  LocalDate jd;
		  try {
		  System.out.println("Enter joindate : ");
		  String date =sc.next();
		  DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		  jd = LocalDate.parse(date, formatter);
		  employee.setJoindate(jd);
		  break;
		  } catch (Exception e) {
			  System.out.println("Invalid date entered..");
		  }
		  }while(true);
		  
		  
		do{
			System.out.println("Enter Mobile no : ");
			String mid= sc.next();
			boolean res=validation.validateMobile_No(mid);
			if(res)
			{
				employee.setMobile_no(mid);
				break;
			}
			else
				System.out.println("Mobile no should be 10 digit.");
		}while(true);
		
		
		try {
			int empid= service.addEmployee(employee);
			System.out.println("Employee added : "+ empid );
		} catch (EmployeeException e) {
			System.out.println(e.getMessage());
		}	
		break;
		
		case 2:
			System.out.println("Enter employee_id ");
			int empid= sc.nextInt();
			employee.setEmployee_id(empid);
			System.out.println("enter Salary ");
			int sal= sc.nextInt();
			
			employee.setEmployee_id(empid);
			employee.setEmployee_id(sal);
			
		try {
			int rev= service.updateEmployee(employee);
			if(rev==1)
				System.out.println("salary updated successfully ");
			else
				System.out.println("id not available");
		} catch (EmployeeException e) {
			System.out.println(e.getMessage());
		}				
		break;
		
		case 3:
			System.out.println("Enter employee id ");
			employee_id= sc.nextInt();
			try {
				int rv= service.deleteEmployee(employee_id);
				if(rv==1)
					System.out.println("employee details deleted .");
				else
					System.out.println("employeeid does not exist");
			} catch (EmployeeException e) {
				System.out.println(e.getMessage());
			}
			
			break;
		}
	}while(true);
	}
}
	
