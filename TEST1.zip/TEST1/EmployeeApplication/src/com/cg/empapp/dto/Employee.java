package com.cg.empapp.dto;

import java.time.LocalDate;

public class Employee {

	private static int employee_id;
	private static String fname;
	private static String lname;
	private static int age;
	private static  String gender;
	private static LocalDate joindate;
	private static String designation;
	private static String mobile_no;
	private static double salary;
	private static int dept_id;
	
	public static int getEmployee_id() {
		return employee_id;
	}
	public void setEmployee_id(int employee_id) {
		this.employee_id = employee_id;
	}
	public static String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public static String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public static int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public static LocalDate getJoindate() {
		return joindate;
	}
	public void setJoindate(LocalDate joindate) {
		this.joindate = joindate;
	}
	public static String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public static String getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(String mid) {
		this.mobile_no = mid;
	}
	public static double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public static String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public static int getDeptid() {
		return dept_id;
	}
	public void setDeptid(int deptid) {
		this.dept_id = deptid;
	}
	
	
	
}
