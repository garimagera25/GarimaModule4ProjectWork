import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
public class Date {
	
	public static void main(String[] args) {
		
		LocalDate date= LocalDate.now();
		System.out.println("Today is:" + date);
	
		Month mon=date.getMonth();
		String name= mon.name();
		//int num= mon.getValue(); represents month in digits
		System.out.println("Month name : " + name); //it will give month name
		int yr= date.getYear();
		System.out.println("year : "+yr); //  it will print year
		int day= date.getDayOfMonth();
		System.out.println("day : "+day); // it will print day
		int dayYear =date.getDayOfYear();
		System.out.println("day of year :"+dayYear); //it will give you the day of the year
		
		DayOfWeek dayOfWeek= date.getDayOfWeek();
		String dayname= dayOfWeek.name();
		//dayOfWeek.getValue();
		System.out.println("day name "+ dayname); //provide with day name
		
		LocalDate dt1= date.plusDays(3);
		System.out.println("Date after 3 days :"+dt1);    
		
		LocalDate dt2= date.plusMonths(3);
		System.out.println("Date after 3 months :"+dt2);
		
		LocalDate dt3= date.plusYears(3);
		System.out.println("Date after 3 years :"+dt3);
		
		LocalDate dt= date.withYear(2016); //it will print the date with year as 2016
		System.out.println(dt);
		
		LocalDate d= date.withDayOfMonth(29);
		System.out.println(d);
		
		boolean res= date.isLeapYear();
		System.out.println("is it a leap year :"+res);
		
		LocalDate dt4= LocalDate.of(2000, 3, 10);//Comparison of two date
		LocalDate dt5= LocalDate.of(2015, 4, 15);
		
		boolean res1=dt4.isBefore(dt5); //whether previous date comes before the next date
		System.out.println(res1);
		
		Period period= Period.between(dt4,dt5); //it will give the duration between two dates
		System.out.println(period);
		
	    Duration duration =Duration.ofHours(4);
	    System.out.println(duration);
	    
	    LocalDateTime time1= LocalDateTime.of(2010, 03, 1, 10, 20, 00, 00);
	    LocalDateTime time2= LocalDateTime.of(2010, 03, 4, 20, 25, 00, 00);
	    
	    Duration duration1= Duration.between(time1, time2);
	    System.out.println(duration1);
	    
	    DateTimeFormatter formatter= DateTimeFormatter.ofPattern("yyyy ,MMMM  dd - E ");//E for day name
	    String formattedDate=formatter.format(date);
	    System.out.println(formattedDate);
		
	}

}
