
public class Str {

	public static void amin(String[] args) {
		String str2="Java Programming";
		String str4= str2.substring(3);
		String str3= str2.substring(2, 7);
		System.out.println("str3 : "+ str3);
		int ind= str2.lastIndexOf('r');
		System.out.println(ind);
	}
}
