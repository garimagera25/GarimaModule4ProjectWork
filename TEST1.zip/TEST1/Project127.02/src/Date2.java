import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.time.LocalDate;

public class Date2 {
	
	public static void main(String[] args) {
		 Scanner sc= new Scanner(System.in);
		 System.out.println("Enter Date (dd/Mon/yyyy ) : ");
		 String dt= sc.next();
		 sc.close();
		 
		 DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd/MMM/yyyy");
		    LocalDate date= LocalDate.parse(dt, formatter);
		    System.out.println(date);
			
	}

}
