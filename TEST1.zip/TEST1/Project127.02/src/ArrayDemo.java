
public class ArrayDemo {

	public static void main(String[] args) {
		String sarr[]={"Hello","Java","Arrays","Module 2"};
		
		for(String str :sarr){
			System.out.println(str);
		}
		//PersonArray[] persons= new PersonArray[5];
		
		//persons[0]= new PersonArray("Neha",23);
		//persons[1]= new PersonArray("Ankita",25);
		//persons[2]= new PersonArray("vishal",30);
		//persons[3]= new PersonArray("rahul",34);
		//persons[4]= new PersonArray("aman",35);
		
		//for(PersonArray person : persons){
		//	System.out.println(person.getName()+""+person.getAge());
		//}
		
	}
}
