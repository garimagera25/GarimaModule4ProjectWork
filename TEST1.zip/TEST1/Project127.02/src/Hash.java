import java.util.HashSet;
import java.util.TreeSet;

public class Hash {
public static void main(String[] args) {
	//HashSet<String> set=new HashSet<>();
	
	//set.add("Hello");
	//set.add("Collections");
	//boolean res=set.add("Servlet");
	//System.out.println(res);
	//set.add("jQuery");
	//set.add("angular JS");
	//set.add("jdbc");
	//res=set.add("Servlet");
	//System.out.println(res);
	//int size=set.size();
	//System.out.println("total elements in set :"+size );
	
	//for(String ele : set){
	//	System.out.println(ele);
	//}
	
	
	TreeSet<String> set=new TreeSet<>(); //tree set is used for sorting
	
	set.add("Hello");
	set.add("Collections");
	set.add("jQuery");
	set.add("angular JS");
	set.add("jdbc");
	int size=set.size();
	System.out.println("total elements in set :"+size );
	
	for(String ele : set){
		System.out.println(ele);
}
}
}
