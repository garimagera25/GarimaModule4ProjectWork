import java.util.Scanner;


public class Main1 {

	public static void main(String[] args) {
		 
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter First Name ");
		String name= sc.next();
		System.out.println("Enter Account no ");
		int accno= sc.nextInt();
		System.out.println("Enter Balance");
		double balance= sc.nextDouble();
		System.out.println(name+" "+accno+" "+balance);
		sc.close();
	}
}
