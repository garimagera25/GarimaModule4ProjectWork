
public class HelloWorld {
	
	public static void main(String[] args) {
		System.out.println("Hello");
		int num = 12;
		
		System.out.println(num);
	}

}
