import java.util.ArrayList;
import java.util.Iterator;

public class BoxingDemo {
public static void main(String[] args) {
	 
	int  num=465;
	Integer obj3= num;
	int num2= obj3;
	System.out.println(num2);

ArrayList<Integer> list= new ArrayList<>();

list.add(57);
list.add(53);
list.add(80);
list.add(44);
list.add(53);
list.add(70);
list.add(4, 56);
//list.addAll(list2);
list.add(40);
list.add(42);

int size = list.size();

System.out.println("Total elements in list : "+ size);

System.out.println(" List elements are :");
//simple for loop
//for(int i=0;i<size;i++){
	//int ele= list.get(i);
	//System.out.println(ele);
	
	//for each loop
	//for(int ele : list){
		
	//System.out.println(ele);
  // }

	
	//using iterator
	Iterator<Integer> itr= list.iterator();
	System.out.println("using iterator ....");
	while(itr.hasNext()){
		int ele= itr.next();
		System.out.println(ele);
		if(ele%10==0)
			itr.remove();
	}
	
	System.out.println("after changes ");
	for(int ele : list){
		
		System.out.println(ele);
  }
}
}
