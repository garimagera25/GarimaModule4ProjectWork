import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class HashDemo {

	public static void main(String[] args) {
		HashMap<Integer, Double> map= new HashMap<>();
		
		map.put(1,  67.86);
		map.put(2,  57.85);
		map.put(3,  60.00);
		map.put(4,  89.00);
		map.put(5,  78.64);
		map.put(3,  67.85); //No duplicate elements are allowed in map if it is there than previous element is replaced by new element.
		map.put(null, null);//hash table does not allow null key 
		
		Set<Entry<Integer, Double>> set= map.entrySet();
		
		Iterator<Entry<Integer,Double>> itr=set.iterator();
		while(itr.hasNext()){
			 Entry<Integer,Double> ele=itr.next();
			int rollno= ele.getKey();
			double percent= ele.getValue();
			System.out.println(rollno + "-> "+percent);
		}
		Set<Integer> keys= map.keySet();
		
		System.out.println(keys);
		Collection<Double> values= map.values();
		
		System.out.println(values);
	}
}
