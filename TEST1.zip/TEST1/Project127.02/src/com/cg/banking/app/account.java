package com.cg.banking.app;
public class account {

	private int accountNo;
	private String accountHolderName;
	private double balance;
	private static double interestRate;
	
	static {
		interestRate=6.0;
	}
	private String accountType;
	
	public static void changeInterestRate(double rate){
		interestRate=rate;
	}
	
	//default constructor
	public account(){
	}
		
	public account(int accno, String name, double balance){
		//parameterized constructor
	accountNo=accno;
	accountHolderName=name;
	this.balance=balance;
	System.out.println("in second");
	}
	public account(int accno, String name, double balance,double rate,String type){
		this(accno,name,balance);//need to be the first statement when u call another constructor
		this.interestRate=rate;
		this.accountType=type;
		System.out.println("third constructor");
}
	//getter method
    public int getAccountNo() {
		return accountNo;
	}
    
    //setter method for accountNo
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public double getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public void withdraw(double amount){
    	
    	if(balance < amount){
    	System.out.println("Insufficient balance !!!");
    	}
    	else
    	{
    		balance=balance-amount;
    		System.out.println(amount + " Rs debited from your Account : "+accountNo);
    	}
    }
    public void deposit(double amount){
    	balance =balance + amount;
    	System.out.println(amount + "Rs credited in your Account : "+accountNo);
    }
    public void printAccountDetails(){
    	System.out.println("accNo : "+ accountNo);
    	System.out.println("Account Holder Name :"+ accountHolderName);
    	System.out.println("balance : "+ balance );
    	System.out.println("interest rate: "+interestRate);
    	System.out.println("account type: "+accountType);
    }
}
