package com.cg.hashset;
import java.util.TreeSet;


public class PersonTreeMain {
public static void main(String[] args) {
	TreeSet<PersonTree> set= new TreeSet<>();
	
	PersonTree p1= new PersonTree("Neha",4,"AWA123");
	PersonTree p2= new PersonTree("Manisha",5,"JIH233");
	PersonTree p3= new PersonTree("Sanvi",7,"TWR453");
    PersonTree p4= new PersonTree("Priya",8,"XYZ183");
    PersonTree p5= new PersonTree("Rahul",6,"HYJ873");
    PersonTree p6= new PersonTree("Vihan",9,"BYD156");
    
    set.add(p1);
    set.add(p2);
    set.add(p3);
    set.add(p4);
    set.add(p5);
    set.add(p6);
    
    for(PersonTree per : set){
    	System.out.println(per);
    }
}
}
