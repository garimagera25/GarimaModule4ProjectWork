package com.cg.hashset;

public class PersonTree implements Comparable<PersonTree>{

	private String name;
	private int age;
	private String aadharNo;
	 public PersonTree(String name,int age,String ano)
	 {
	 this.name=name;
	 this.age=age;
	 this.aadharNo= ano;
	 
	 
}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	@Override
	public String toString(){
		return name+ " "+ age +" "+ aadharNo;
	}
	@Override
	public int compareTo(PersonTree person){
		return this.name.compareTo(person.getName());
	}
}
