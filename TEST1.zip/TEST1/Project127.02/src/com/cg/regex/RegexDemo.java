package com.cg.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;

public class RegexDemo {
 public static void main(String[] args) {
	//String str="11:32:43:74";
	//String nums[]= str.split(":");
	
	//for(int i=0;i<nums.length;i++)
		
		//System.out.println(nums[i]);
	
	//String str="Hello, How are You ? ,How is the day ?";
	
	//str=str.replaceAll("[A-Z]", "regex");
	//System.out.println(str);
	
	Pattern pattern = Pattern.compile("^[A-Z][a-z]+$");//input validation +$ means one or more
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Your name : ");
	String str= sc.next();
	Matcher matcher = pattern.matcher(str);
	
	boolean res=matcher.matches();
	
	if( res )
		System.out.println("name is valid ");
	else
			System.out.println("invalid name ");
	
	
	Scanner sc1=new Scanner(System.in);
	System.out.println("Enter mobile no as XXX-XXX-XXXX : ");
	String str1= sc.next();
	boolean res1=Pattern.matches("[0-9]{2}-[0-9]{3}-[0-9]{4}" , str1);//[0-2]
	if (res){
		System.out.println("valid mobile no ");
	}
	else
		System.out.println("invalid mobile no. ");
	
	}
}
