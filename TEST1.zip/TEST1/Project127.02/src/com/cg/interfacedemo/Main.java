package com.cg.interfacedemo;

public class Main {

	public static void main(String[] args) {
		CalcImp1 calc=new CalcImp1();
		int num= calc.add(45, 573);
		System.out.println("addition : "+ num);
		int res= calc.subtract(45, 7);
		System.out.println("subtraction :" + res);
	}
}
