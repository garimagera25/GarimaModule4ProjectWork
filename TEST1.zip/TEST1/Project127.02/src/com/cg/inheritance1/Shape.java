package com.cg.inheritance1;
public class Shape {
	String name;
	
	Shape()
	{
		name="No name for shape";
		System.out.println("default constr: Shape");
	}
	public void draw()
	{
		System.out.println("we can draw any shape");
	}

}
