package com.cg.inheritance1;
public class Rectangle {
	
	public class Rectangle1 extends Shape {
		
		int length,breadth;
		int area;
		Rectangle1(int l,int b){
			length=l;
			breadth=b;
		}
		public void draw(){
			System.out.println("In Rectangle class.");
		}
		public void calcArea(){
			area=length*breadth;
			System.out.println("area of Rectangle : "+ area);
		}
	}

}