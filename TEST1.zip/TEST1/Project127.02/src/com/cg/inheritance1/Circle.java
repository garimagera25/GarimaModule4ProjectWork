package com.cg.inheritance1;
public class Circle extends Shape{

    double radius;
	double area;
	
	Circle()
	{
		super.draw();
		super.name="Circle";
		System.out.println("default constr :circle  ");
	}
	Circle(double radius){
		//super();
		this.radius=radius;
	}
	public void draw(){
		System.out.println("draw the circle ");
	}
	
	public void calcArea(){
		super.draw();
		area= Math.PI*radius*radius;
		System.out.println("area of circle :"+ area);
	}
	
	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}

	public double getArea() {
		return area;
	}

	public void setArea(double area) {
		this.area = area;
	}

}
