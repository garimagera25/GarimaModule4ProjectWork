package com.cg.inheritance1;


public class ShapeMain {

public static void main(String[] args) {
	//Circle circle= new Circle();
	//circle.setRadius(5);
	//circle.calcArea();
	//circle.draw();
	Shape shape= new Circle(5);
	shape.draw();
	((Circle) shape).setRadius(6);
	((Circle) shape).calcArea();
	
	
}	

}
