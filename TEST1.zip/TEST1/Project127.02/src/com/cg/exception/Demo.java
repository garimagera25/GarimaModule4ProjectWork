package com.cg.exception;

import java.util.Scanner;

public class Demo {

	public static void validateAge(int age){
		try{
		if(age < 18)
			throw new AgeException(age);
		System.out.println("You are valid for registration ..");
	}
		catch(AgeException e){
			e.printError();
		}
		}
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Age : ");
		int age= sc.nextInt();
		validateAge(age);
		sc.close();
	}
}
