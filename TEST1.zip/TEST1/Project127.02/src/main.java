import com.cg.banking.app.account;
public class main {

	public static void main(String[] args) { 
		account acc1= new account(34621,"Pravin",23000,8.6,"saving");
		acc1.printAccountDetails();
		account.changeInterestRate(5.8);
		
		//acc1.setAccountNo(34621);
		//acc1.setAccountHolderName("Pravin");
		//acc1.setAccountType("Saving");
		//acc1.setBalance(23000);
		//acc1.setInterestRate(6.5);
		
		
		//acc1.printAccountDetails();
		//acc1.withdraw(25000);
		
	}
}
