package com.cg.eis.pl;

import com.cg.eis.bean.Employee;

public class UserInput {
	public static void main(String[] args) {
		Employee es=new Employee(102,"varnika",500,"Manager");
		es.insuranceScheme(40000, "Manager");
		es.checkSalary();
		es.display();
	}
}
