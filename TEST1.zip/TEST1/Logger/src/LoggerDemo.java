import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.logger.demo.Calculator;
public class LoggerDemo {
public static void main(String[] args) {
	
	PropertyConfigurator.configure("Resources/log4j.properties");
	Calculator cal=new Calculator();
	Logger logger= Logger.getLogger(LoggerDemo.class);
	System.out.println("Please see the basic.log file for log messages ...");
	int addres=cal.add(46, 74);
	int subres=cal.subtract(73, 34);
	double divres=cal.divide(354, 0);
	int mulres=cal.multiply(5, 4);
	
	logger.info("Addition result : "+ addres);
	logger.info("Subtraction result : "+ subres);
	logger.info("Multiplication result : "+ mulres);
	logger.info("Divide result : "+ divres);
	
	
	logger.debug("this is a debug level message ");
	logger.info("this is a info message");
	logger.warn("this is a warn level message");
	logger.error("this is a error level message");
	logger.fatal("this is a fatal level message");
}
}
