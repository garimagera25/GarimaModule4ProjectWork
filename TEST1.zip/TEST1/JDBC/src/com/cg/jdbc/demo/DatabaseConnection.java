package com.cg.jdbc.demo;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.util.Properties;
//import com.sun.corba.se.pept.transport.Connection;

public class DatabaseConnection {
	
	
public static Connection getConnection()
{
Connection con=null;
//Connection parameters

String url;
String user;
String password;
String driver;
//String url="jdbc:oracle:thin:@localhost:1521:xe";
//String user="System";
//String password="corp123";

try{
	InputStream file= new FileInputStream("./Resources/newfile.properties");
	Properties prop= new Properties();
	prop.load(file);
	url= prop.getProperty("url");
	user= prop.getProperty("user");
	password= prop.getProperty("password");
	driver= prop.getProperty("driver");

	Class.forName(driver);
Class.forName("oracle.jdbc.driver.OracleDriver");
con=DriverManager.getConnection(url, user, password);
System.out.println("database connected..");
file.close();
} catch (ClassNotFoundException e){
	System.out.println("Driver class not loaded ..");
} catch (SQLException e) {
	System.out.println("error while connecting db ");
} catch (IOException e) {
	System.out.println("file not open");
}
return con;

}

public static void main(String[] args){
	getConnection();
}
}


