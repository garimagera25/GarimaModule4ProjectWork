package com.cg.jdbc.demo;

import java.sql.Connection;
//import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.time.LocalDate;
import java.sql.Statement;

public class InsertDemo {
public static void main(String[] args) {
	 Connection con= DatabaseConnection.getConnection();
	 
	 String insQuery="insert into employee_masters"
			 + " (empid,empname,salary,joindate,deptid) "
			 + " values (emp_id_seq.nextval,?,?,sysdate,? ) ";
	 try {
		 PreparedStatement ps= con.prepareStatement(insQuery);
		 
		 //ps.setInt(1, 129);
		 ps.setString(1, "Aman");
		 ps.setDouble(2, 3400.00);
		 
		// LocalDate jdate= LocalDate.of(2016,12 ,24 );
		// ps.setDate(4, Date.valueOf(jdate));
		 
		 ps.setInt(3, 2);
		 int r= ps.executeUpdate();
		 
		 String sql="select emp_id_seq.currval from dual";
		 Statement stmt=con.createStatement();
		 ResultSet rs= stmt.executeQuery(sql);
		 int empid=0;
		 if(rs.next())
	     empid=rs.getInt(1);
		 System.out.println(r +"rows inserted ....");
		 System.out.println("employee record inserted with empid : "+ empid);
	 }
	 catch(SQLException e)
	 {
		 e.printStackTrace();
	 }
}
}
