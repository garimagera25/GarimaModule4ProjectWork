package com.cg.jdbc.demo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class SelectDemo {

	public static void main(String[] args) { 
		
		Connection con =DatabaseConnection.getConnection();
		
		String selQuery= "select deptid,deptname from department_masters ";
		
		try
		{
		Statement stmt= con.createStatement();
		ResultSet rs= stmt.executeQuery(selQuery);
		while(rs.next()){
			int deptid= rs.getInt("deptid");
			String dname=rs.getString("deptname");
			
			System.out.println(deptid+""+dname);
		}
		rs.close();
		con.close();
		
		} catch (SQLException e){
			e.printStackTrace();
		}
}
}
