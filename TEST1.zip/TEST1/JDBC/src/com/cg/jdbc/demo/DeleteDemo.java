package com.cg.jdbc.demo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteDemo {

	public static void main(String[] args) {
	
		 Connection con= DatabaseConnection.getConnection();
		 
		 String delQuery="DELETE FROM employee_masters WHERE deptid=?";
		 PreparedStatement ps;
		 try {
			 ps = con.prepareStatement(delQuery);
			 ps.setInt(1, 2);
			 int r=ps.executeUpdate();
			 
			 System.out.println(r +" rows deleted...");
		 } catch (SQLException e){
			 e.printStackTrace();
		 }
	}
}
