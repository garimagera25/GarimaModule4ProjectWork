
public class Series {
public static void main(String[] args) {
	int arr[]={1,2,3};
	for(int var:arr){
		int i=1;
		while(i<=var);
		System.out.println(i++);
	}
}
}
