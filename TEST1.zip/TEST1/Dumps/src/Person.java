class Person{
	int enrollments;
}
class TestEJavaCourse{
	public static void main(String args[]) {
		Person p1=new Person();
		Person p2=new Person();
		p1.enrollments=100;
		p2.enrollments=200;
		System.out.println(p1.enrollments+p2.enrollments);
	}
}