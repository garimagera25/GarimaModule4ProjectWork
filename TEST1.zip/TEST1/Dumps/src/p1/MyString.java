package p1;
class MyString {
String msg;
MyString(String msg) {
this.msg=msg;
}
}
