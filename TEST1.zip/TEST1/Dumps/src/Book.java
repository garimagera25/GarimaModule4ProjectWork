import java.util.*;

class Book1{
public static void main(String[] args) {
	ArrayList<String> seasons=new ArrayList<>();
	seasons.add(1,"Spring");
	seasons.add(2,"Summer");
	seasons.add(3,"Autumn");
	seasons.add(4,"Winter");
	seasons.remove(2);
	for(String s:seasons)
		System.out.println(s+",");
}
}
