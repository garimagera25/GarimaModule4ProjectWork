class XY {
static void m(int i){
	i+=7;
	System.out.println(i);
}
public static void main(String[] args) {
	int j=12;
	m(j);
	System.out.println(j);
}
}
