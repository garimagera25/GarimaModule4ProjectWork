
class Question {
String type="4W";
int maxSpeed=100;

Question(String type,int maxSpeed){
	this.type=type;
	this.maxSpeed=maxSpeed;
}
}
class Car extends Question{
	String trans;
	Car(String trans){
		this.trans=trans;
	}
	Car(String type,int maxSpeed,String trans){
		super(type,maxSpeed);
		this(trans);
	}
}


