
public class Test2 {
int fvar;
static int cvar;
public static void main(String[] args) {
	Test2 t=new Test2();
	Test2.cvar=200;
	t.fvar=400;
	System.out.println(cvar);
	
}
}
