import java.util.*;

public class PersonMain25 {
public static void main(String[] args) {
	Person25 per=new Person25();
	
	System.out.println("Person Details");
	Scanner sc=new Scanner(System.in);
	System.out.println("enter first name");
	String fname=sc.next();
	System.out.println("enter last name");
	String lname=sc.next();
	System.out.println("enter gender");
	String gen=sc.next();
	switch(gen)
	{
	case "M": per.setGender(Gender.m);break;
	case "F": per.setGender(Gender.f);break;
	case "m": per.setGender(Gender.m);break;
	case "f": per.setGender(Gender.f);break;
	default: System.out.println("cannot take other characters");
	
	}
	
	sc.close();
	
	per.gender.display();
}
}
