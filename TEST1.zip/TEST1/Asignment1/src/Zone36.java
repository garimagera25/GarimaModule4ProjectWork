
import java.time.*;
import java.util.*;

public class Zone36 {
public static void main(String[] args) {

	 Scanner sc= new Scanner(System.in);
     System.out.println("Enter zone");
     String ZoneEntered= sc.next();
     
     ZoneId zone1=ZoneId.of(ZoneEntered);
     LocalTime now1=LocalTime.now(zone1);
     System.out.println(now1);
     sc.close();
}
}
