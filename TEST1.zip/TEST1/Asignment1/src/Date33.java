
import java.time.Duration;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Date33 {

public static void main(String[] args) {
		
		LocalDate date= LocalDate.now();
		System.out.println("Today is:" + date);
		
		Scanner sc= new Scanner(System.in);
		 System.out.println("Enter Date (dd/Mon/yyyy ) : ");
		 String dt= sc.next();
		 
		 
		 DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd/MMM/yyyy");
		    LocalDate date1= LocalDate.parse(dt, formatter);
		    System.out.println(date1);
		    
		    Period period= Period.between(date,date1); //it will give the duration between two dates
			System.out.println(period);				    
			    
}
}