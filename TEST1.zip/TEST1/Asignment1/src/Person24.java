
public class Person24 {
	String firstName;
	String lastName;
	char gender;
	long PhoneNo=0L;
	
	
	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public char getGender() {
		return gender;
	}


	public void setGender(char gender) {
		this.gender = gender;
	}

	public Person24(String firstName,String lastName,char gender)
	{
		this.firstName=firstName;
		this.lastName=lastName;
		this.gender=gender;
	}
	
	public void getPhoneNumber(long phoneno)
	{
		this.PhoneNo=phoneno;
		System.out.println("phone number="+phoneno);
	}

	public long getPhoneNo() {
		return PhoneNo;
	}


	public void setPhoneNo(long phoneNo) {
		this.PhoneNo = phoneNo;
	}
     public Person24()
     {
       //default constructor
     }
	void printperson24details()
	{ //parameterized constructor
	System.out.println("firstName="+firstName);
	System.out.println("lastName="+lastName);
	System.out.println("gender="+gender);
	}
}
