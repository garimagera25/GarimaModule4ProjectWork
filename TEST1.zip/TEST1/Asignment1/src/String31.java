import java.util.Scanner;

public class String31 {
	private String UserString;
	private int UserChoice;
	
	public void PrintOutput()
	{
		System.out.println("user choice is"+UserChoice);
	}
	public void ReplaceOdd(String UserString)
	{
		StringBuilder UserStringRep = new StringBuilder(UserString);
		for(int i=0;i<UserString.length();i++)
		{
			
			if(i%2==0)
			{
				//     string is immutable in java UserString[i]="#";
				
				UserStringRep.setCharAt(i, '#');
			}
			
		}
		System.out.println(UserStringRep);
	}
	public void RemoveDuplicate(String UserString)
	{
		String temp="";
		String 	UserStringDup="";
		for(int i=0;i<UserString.length();i++)
		{
			temp="";
			temp+=UserString.charAt(i);
	//		System.out.println("here"+temp);
			int count=0;
			for(int j=0;j<UserString.length();j++)
			{
			//	System.out.println("her....e"+temp);
				if(UserString.charAt(j) == temp.charAt(0) ){
	//				System.out.println("this is "+temp);
	//				System.out.println(UserString.charAt(j));
	//				System.out.println(temp.charAt(0));
					count++;
					System.out.println("count is"+count);
					
				}
				
			}
			if(count==1)
			{
				UserStringDup+=temp;
			}
		}
		System.out.println(UserStringDup);
	}
	
	
	public void UpperCase(String UserString)
	{
		String temp="";
		String UserStringUpp="";
		for(int i=0;i<UserString.length();i++)
		{
			temp="";
			temp +=UserString.charAt(i);
			if(i%2==0)
			{
				temp = temp.toUpperCase();
				UserStringUpp+=temp;
			}
			else
				UserStringUpp+=temp;
			
		}
		System.out.println(UserStringUpp);
	}
	
	
	public String getUserString() {
		return UserString;
	}
	
	public void setUserString(String userString) {
		UserString = userString;
	}
	
	public int getUserChoice() {
		return UserChoice;
	}
	
	public void setUserChoice(int userChoice) {
		UserChoice = userChoice;
	}
}