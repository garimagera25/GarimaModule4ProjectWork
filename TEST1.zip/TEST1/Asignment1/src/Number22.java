
public class Number22 {

	public static void main(String[] args) {
		System.out.println(Integer.parseInt(args[0]));
		if(Integer.parseInt(args[0])>0)
		System.out.println("Number is positive");
		else
		System.out.println("Number is negative");
	}
}
