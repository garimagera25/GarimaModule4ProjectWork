package com.cg.banking.app;

public class Person1Main {
 String firstName;
 String lastName;
 char gender;
 double PhoneNo;
}
