package com.cg.exception;

public class AccountMain {
public static void main(String[] args) {
	
	 Person p1= new Person("Smith",45);
	 Person p2= new Person("Kathi",34);
	 
	 Account41 acc1=new Account41();
	 acc1.setBalance(2000);
	 acc1.setAccHolder(p1);
	 acc1.deposit(2000);
	 acc1.printAccountDetails();
	 
	 Account41 acc2=new Account41();
	 acc2.setBalance(3000);
	 acc2.setAccHolder(p2);
	 acc2.printAccountDetails();
	 
	Account41 sav=new SavingsAccount();
	sav.setBalance(5000);
	sav.withdraw(4000);
	Account41 cur=new CurrentAccount();
	sav.setBalance(200000);
	sav.withdraw(6000);
}
}
