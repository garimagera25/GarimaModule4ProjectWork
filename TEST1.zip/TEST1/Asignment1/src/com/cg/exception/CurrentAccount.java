package com.cg.exception;

public class CurrentAccount extends Account41 {
	final double overdraftlimit=100;
	@Override
	public void withdraw(double amount)
	{
		
		if(amount>overdraftlimit)
		{
			System.out.println("overdraftlimit is reached");
		}
		else
		{
			result();
			super.withdraw(amount);
		}
	}
	private boolean result()
	{
		return true;
	}
}
