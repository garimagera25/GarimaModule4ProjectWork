package com.cg.exception;

public class Account41 {

	int accNo;
	double balance;
	Person  accHolder;
	private static int count=1000;
	
	public Account41()
	{
		count++;
		accNo=count;
		
	}
	public Account41(double balance)
	{
		this.balance=balance;
		System.out.println("in second");
	}

	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Person getAccHolder() {
		return accHolder;
	}

	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	public String toString()
    {
    	return accNo+ ":"+balance+":"+accHolder;
    }

	
public void withdraw(double amount){
    	
    	balance=balance-amount;
    	System.out.println(+balance+" debited from your Account : "+accNo);
    	System.out.println("updated balance is:"+balance);
    	}
    public void deposit(double amount){
    	balance =balance +amount;
    	System.out.println(+balance+" debited from your Account : "+accNo);
    	System.out.println("updated balance is:"+balance);
    }
    public void printAccountDetails(){
    	System.out.println("accNo : "+ accNo);
    	System.out.println("Account Holder :"+ accHolder);
    	System.out.println("balance : "+ balance );
	
}
    
}

