package com.cg.exception;

public class SavingsAccount extends Account41{
final double minBalance=500;
@Override
public void withdraw(double amount)
{
	if(amount<minBalance)
	{
		System.out.println("less than minimumbalance ");
	}
	else
	{
		super.withdraw(amount);
	}
}
}
