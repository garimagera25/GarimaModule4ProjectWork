package com.cg.assignmentarray;
import java.util.Arrays;

public class Array72 {
	public static void main(String[] args) {
		
		Product72 p1= new Product72("Television");
		Product72 p2= new Product72("Laptop");
		Product72 p3= new Product72("Soap");
		Product72 p4= new Product72("Chocolate");
		
		Product72 arr[]= new Product72[4];
		arr[0]= p1;
		arr[1]= p2;
		arr[2]= p3;
		arr[3]= p4;
		
		Arrays.sort(arr, new CompImp());
		for(Product72 Product72 : arr ){
			System.out.println(Product72);
		}
	}
}
