package com.cg.assignmentarray;
public class Product72 {

	String Productname;
	
	public Product72(String name) {
		this.Productname= name;
	}
	

	public String getProductname() {
		return Productname;
	}


	public void setProductname(String productname) {
		Productname = productname;
	}


	
	public String toString() {
		return Productname;
	}

}
