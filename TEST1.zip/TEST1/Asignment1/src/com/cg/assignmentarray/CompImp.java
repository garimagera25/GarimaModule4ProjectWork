package com.cg.assignmentarray;
import java.util.Comparator;
public class CompImp implements Comparator<Product72> {

		@Override
		public int compare(Product72 person1, Product72 person2) {
			String name1= person1.getProductname();
			String name2= person2.getProductname();
			return name1.compareTo(name2);
		}

	}
