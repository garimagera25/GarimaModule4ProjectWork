package com.cg.assignmentarray;

import java.util.Arrays;

public class Array71 {
	public static void main(String[] args) {
	
		String arr[]={"Laptop","Television","Soap","Chocolate"};
		Arrays.sort(arr);
		for(String str :arr){
			System.out.println(str);
}
}
}