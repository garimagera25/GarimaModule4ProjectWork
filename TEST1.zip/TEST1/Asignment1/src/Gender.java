
public enum Gender {

		m("Male"),f("Female");
		String gender;
		Gender(String gen)
		{
			gender=gen;
		}



		public String getName()
		{
			return gender;
		}
		public void display()
		{
			System.out.println(gender);
		}
	}


