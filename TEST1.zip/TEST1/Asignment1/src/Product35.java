
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.Period;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
public class Product35 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Accept Purchase Date (dd/Mon/yyyy ) : ");
		String dt1= sc.next();
		
		 DateTimeFormatter formatter= DateTimeFormatter.ofPattern("dd/MMM/yyyy");
		    LocalDate date= LocalDate.parse(dt1, formatter);
		    System.out.println(date);
		
		LocalDate dt2= date.plusMonths(5);
		System.out.println("Warrantee after 5 months :");
		
		DateTimeFormatter formatter1= DateTimeFormatter.ofPattern("dd/MMM/yyyy"); 
	    System.out.println("Warrantee of Product expires:"+dt2);
}
}