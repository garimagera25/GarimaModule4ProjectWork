
import java.time.Duration;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Date34 {
	
	public static void main(String[] args) {

		 Scanner sc= new Scanner(System.in);
	System.out.println("Enter Date (dd/Mon/yyyy ) : ");
	 String dt1= sc.next();
	 
	 
	 DateTimeFormatter formatter1= DateTimeFormatter.ofPattern("dd/MMM/yyyy");
	    LocalDate date2= LocalDate.parse(dt1, formatter1);
	    System.out.println(date2);
	    
	    
	    
		 System.out.println("Enter Date (dd/Mon/yyyy ) : ");
		 String dt2= sc.next();
		
		 
		 DateTimeFormatter formatter2= DateTimeFormatter.ofPattern("dd/MMM/yyyy");
		    LocalDate date3= LocalDate.parse(dt2, formatter2);
		    System.out.println(date3);
		    
		    
		    
		    Period period1= Period.between(date3,date2); //it will give the duration between two dates
			System.out.println(period1);
			}
}
