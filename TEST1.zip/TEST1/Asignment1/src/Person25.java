
public class Person25 {

    String firstName;
	String lastName;
	Gender gender;
	long PhoneNo;
	
	public Person25()
	{
		
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public Person25(String firstName,String lastName,Gender gender)
	{
		this.firstName=firstName;
		this.lastName=lastName;
		this.gender=gender;
	}
	public void getPhoneNumber(long phoneno)
	{
		this.PhoneNo=phoneno;
		System.out.println("phone number="+phoneno);
	}
	public long getPhoneNo() {
		return PhoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.PhoneNo = phoneNo;
	}
	
	void printPerson25details()
	{
		System.out.println("firstname="+firstName);
		System.out.println("lastname="+lastName);
		System.out.println("Gender="+gender);
	}
	
}