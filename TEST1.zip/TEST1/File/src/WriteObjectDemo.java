import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import com.cg.files.demo.Person;


public class WriteObjectDemo {

	public static void main(String[] args) {
		
		Person p1=new Person("Smith","male",43);
		Person p2=new Person("Kathy","female",33);
		Person p3=new Person("Sammy","female",53);
		
		try {
			FileOutputStream fos= new FileOutputStream("PersonDetails.dat");
		    ObjectOutputStream oos= new ObjectOutputStream(fos);
		    oos.writeObject(p1);
		    oos.writeObject(p2);
		    oos.writeObject(p3);
		    System.out.println("person objects written into file..");
		    oos.close();
		    
	} catch (FileNotFoundException e) {
		
	} catch (IOException e) {
		e.printStackTrace();
	}
}
}
