import java.io.File;
import java.util.Date;


public class FileOperations {

	public static void main(String[] args) throws Exception {
		File file= new File("DEmo.txt");
		
		boolean res1=file.createNewFile();
		if(res1)
		System.out.println("file created..");
		
		//file.delete();
		System.out.println("IS it a file ? "+ file.isFile());
		System.out.println("IS it a directory "+ file.isDirectory());
		
		System.out.println("Path : "+file.getAbsolutePath());
		
		Date date= new Date(file.lastModified());
		System.out.println("Last Modified Date :" +date);
		boolean res=file.setReadOnly();
		if(res)
			System.out.println("now the file is read only ..");
		file.setReadOnly();
	}
}