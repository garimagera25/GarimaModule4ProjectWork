import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

import com.cg.files.demo.Person;


public class ReadObjects {

	public static void main(String[] args) {
		
		try {
		FileInputStream fin = new FileInputStream("PersonDetails.dat");
		ObjectInputStream ois= new ObjectInputStream(fin);
		
		for(int i=1;i<=3;i++) {
		Person p1= (Person) ois.readObject();
		
		System.out.println("Name : "+p1.getName());
		System.out.println("Age : "+p1.getAge());
		System.out.println("Gender : "+p1.getGender());
		}
		ois.close();
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	} catch (IOException e) {
		e.printStackTrace();
	} catch (ClassNotFoundException e) {
		e.printStackTrace();
	}
}
}