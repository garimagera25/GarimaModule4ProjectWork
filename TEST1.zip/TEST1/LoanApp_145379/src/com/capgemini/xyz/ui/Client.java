package com.capgemini.xyz.ui;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.xyz.exception.LoanException;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.service.LoanService;
import com.capgemini.xyz.service.ILoanService;
import com.capgemini.xyz.ui.Client;
import com.capgemini.xyz.service.ValidationService;
import  com.capgemini.xyz.service.ValidationServiceImpl;

public class Client {

	public static void main(String[] args) {
	PropertyConfigurator.configure("resources/newfile.properties");
	Customer customer= new Customer();
	Loan loan=new Loan();
	Logger logger=Logger.getLogger(Client.class);
	ValidationService validation=new ValidationServiceImpl();
	ILoanService service= new LoanService();
	Scanner sc = new Scanner(System.in);
	int option=0;
	
	do{
    System.out.println("\n\n1.Register Customer...");
	System.out.println("2. Exit");
	System.out.println("Enter Choice .");
	option= sc.nextInt();
	switch(option){
	case 1:
		
		do {
				System.out.println("Enter Customer Name : ");
				String name1 =sc.next();
				boolean res=validation.validateCustName(name1);
				if(res==true)
				{
					customer.setCustName(name1);
					break;
				}
				else
					System.out.println("Name should contain only alphabets");
				}while(true);
		
		do{
			System.out.println("Enter Address : ");
			String name2 =sc.next();
			boolean res=validation.validateAddress(name2);
			if(res==true)
			{
				customer.setAddress(name2);
				break;
			}
			else
				System.out.println("Address should be valid");
			}while(true);
		
		do{
			System.out.println("Enter Email : ");
			String mail= sc.next();
			boolean res= validation.validateEmail(mail);
			if(res==true)
				{
					customer.setEmail(mail);
					break;
				}
				else
					System.out.println("Mail id as:abcd@capgemini.com ");	
		}while(true);
		
		do{
			System.out.println("Enter mobile No :");
			String mobno= sc.next();
			boolean res=validation.validateMobile(mobno);
			if(res)
			{
				customer.setMobile(mobno);
				break;
			}
			else
				System.out.println("Mobile no should be 10 digit.");
		}while(true);
			
		
		
		try {
			long custid=service.insertCust(customer);
		System.out.println("Customer information saved successfully: "+ custid);
		logger.info("Customer information saved successfully: "+ custid);
		} catch (LoanException e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());
		}
		System.out.println("1.  Register for loan request");
		System.out.println("2. Exit");
		System.out.println("Do you wish to apply for loan");
		option=sc.nextInt();
		switch(option)
		{
		case 1:
			System.out.println("Enter your customer Id");
			long custid=sc.nextLong();
			System.out.println("Enter loan amount");
			double amount=sc.nextDouble();
			System.out.println("Enter duration in years");
			int duration=sc.nextInt();
			loan.setLoanAmount(amount);
			loan.setCustId(custid);
			loan.setDuration(duration);
			try{
				double emi=service.calculateEMI(amount, duration);
				System.out.println("For loan amount="+amount+ "and"+duration+"Years duration.Your EMI per month will be"+emi);
				logger.info("For loan amount="+amount+ "and"+duration+"Years duration.Your EMI per month will be"+emi);
				int choice=0;
				System.out.println("Do you want to apply for loan");
				System.out.println("pres 1 to apply for loan");
				System.out.println("press 2 for exit");
				System.out.println("enter your choice");
				choice=sc.nextInt();
				
				switch(choice)
				{
				case 1:
					long loanid=service.applyLoan(loan);
					System.out.println("Your loan request is generated.Your Loan ID is "+loanid);
					logger.info("Your loan request is generated.Your Loan ID is "+loanid);
				case 2: 
					System.out.println("Your loan request is not generated");
					logger.info("Your loan request is not generated");
				}
				} catch (LoanException e) {
					logger.error(e.getMessage());
					System.out.println(e.getMessage());
				} break;
				
				case 2:
					break;
					default:System.out.println("thank you");
					logger.info("thank you");
				}
			break;
		case 2:
			break;
			default: System.out.println("process terminated");
			logger.info("process terminated");
				}
		}while(option!=3);
	}
	}
