import java.util.function.Consumer;
import java.util.function.Supplier;


public class PersonLambda {

	public static void main(String[] args) {
		
		Person p1=new Person();
		Consumer<String> con=p1::setName;
		con.accept("Smith");
		
		Consumer<Integer> con1 = p1::setAge;
		
		con1.accept(23);
		
		Supplier<String> sup1 = ()-> p1.getName();
		
		Supplier<String> sup2 = ()-> p1.getName();
		
		System.out.println(sup1.get()+" "+ sup2.get());
				
	}
}
