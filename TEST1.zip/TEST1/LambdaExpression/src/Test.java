@FunctionalInterface
public interface Test {

	public boolean test(int num);
}
