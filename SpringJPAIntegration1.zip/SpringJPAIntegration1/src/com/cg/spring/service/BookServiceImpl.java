package com.cg.spring.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.dao.BookRepository;
import com.cg.spring.entities.Author;
import com.cg.spring.entities.BookDetails;

@Transactional
@Service
public class BookServiceImpl implements BookService {

	@Autowired
	BookRepository repository;
	
	public BookRepository getRepository() {
		return repository;
	}

	public void setRepository(BookRepository repository) {
		this.repository = repository;
	}

	@Override
	public List<Author> getAuthorList() {
		return repository.getAuthorList();
	}

	@Override
	public BookDetails addBookDetails(BookDetails book) {
		return repository.addBookDetails(book);
	}

	@Override
	public List<BookDetails> getBookList() {
		return repository.getBookList();
	}

	@Override
	public BookDetails getBookDetails(int bookid) {
		return repository.getBookDetails(bookid);
	}

	@Override
	public BookDetails updateBook(BookDetails book) {
		return repository.updateBook(book);
	}

	@Override
	public BookDetails removeBook(int bookid) {
		return repository.removeBook(bookid);
	}

}
