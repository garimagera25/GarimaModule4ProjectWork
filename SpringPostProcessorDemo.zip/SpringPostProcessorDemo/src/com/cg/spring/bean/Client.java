package com.cg.spring.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
		DatabaseConnection con=(DatabaseConnection) context.getBean("dbcon");
		System.out.println(con.getUrl());
		System.out.println(con.getUserName());
		System.out.println(con.getPassword());
		System.out.println(con.getDriver());
	}
}
