package com.cg.demotwojpa.dao;

import com.cg.demotwojpa.dto.Project;

public interface IProjectDao {

	public int addProject(Project proj);
	public void removeProject(int projId);
	public Project findProject(int projId);
}
