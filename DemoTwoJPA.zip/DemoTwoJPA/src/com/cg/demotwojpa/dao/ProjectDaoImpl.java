package com.cg.demotwojpa.dao;

import javax.persistence.EntityManager;

import com.cg.demotwojpa.dto.Project;

public class ProjectDaoImpl implements IProjectDao {

	EntityManager em;
	
	public  ProjectDaoImpl() {
		em=ProjectUtil.getEntityManager();
	}
	@Override
	public int addProject(Project proj) {
		em.getTransaction().begin();
		em.persist(proj);
		em.getTransaction().commit();
		return 0;
	}

	@Override
	public void removeProject(int projId) {
		em.getTransaction().begin();
		Project eremove=em.find(Project.class,1001);
		em.getTransaction().commit();
	}

	@Override
	public Project findProject(int projId) {
		em.getTransaction().begin();
		Project efind=em.find(Project.class,1002);
		return efind;
	}

	

}
