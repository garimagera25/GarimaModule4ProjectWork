package com.cg.demotwojpa.service;

import com.cg.demotwojpa.dto.Project;

public interface IProjectService {

	public int addProject(Project proj);
	public void removeProject(int projId);
	public Project findProject(int projId);
	
}
