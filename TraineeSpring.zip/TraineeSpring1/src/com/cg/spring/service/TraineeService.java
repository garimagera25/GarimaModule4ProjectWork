package com.cg.spring.service;

import java.util.List;

import com.cg.spring.entities.Trainee;

public interface TraineeService {
 
	public Trainee addTrainee(Trainee trainee); 
    public Trainee removeTrainee(int traineeId);
    public Trainee getTrainee(int traineeId);
	public Trainee updateTrainee(Trainee trainee);
	public List<Trainee> getDetails();
}
