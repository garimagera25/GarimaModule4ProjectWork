package com.cg.spring.service;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.dao.TraineeRepository;
import com.cg.spring.entities.Trainee;

@Transactional
@Service
public class TraineeServiceImpl implements TraineeService{

	@Autowired
	TraineeRepository repository;
	
	
	public TraineeRepository getRepository() {
		return repository;
	}


     public void setRepository(TraineeRepository repository) {
		this.repository = repository;
	}

     @Override
	public Trainee addTrainee(Trainee trainee) {
		return repository.addTrainee(trainee);
	}


	@Override
	public Trainee removeTrainee(int traineeId) {
		return repository.removeTrainee(traineeId);
	}


	@Override
	public Trainee getTrainee(int traineeId) {
		return repository.getTrainee(traineeId);
	}


	@Override
	public Trainee updateTrainee(Trainee trainee) {
		return repository.updateTrainee(trainee);
	}


	@Override
	public List<Trainee> getDetails() {
		return repository.getDetails();
	}

}
