package com.cg.spring.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.spring.entities.Trainee;
import com.cg.spring.service.TraineeService;

@Controller
public class TraineeController {

	@Autowired
	TraineeService service;
	
	@RequestMapping("/login")
	private String ValidatePage(Model model,@RequestParam("username") String uname,@RequestParam("pwd") String password)
	{
	if(uname.equals("admin") && password.equals("admin123"))
	{
		return "index";
	}
	else
	{
		model.addAttribute("Error","Username and Password is Wrong");
		return "Error";
	}
}

	@RequestMapping("/addTraineePage")
	public String AddTrainee(Model model){
		Trainee trainee=new Trainee();
		//List<Trainee> list=service.getTraineeList();
		//model.addAttribute("traineeList",list);
		model.addAttribute("trainee", trainee);
		return "AddTraineeDetails";
	}
	
	@RequestMapping("/insertTrainee")
	public String insertTraineeRecord(Model model,@ModelAttribute("trainee") Trainee trainee)
	{
		System.out.println("in trainee");
		trainee=service.addTrainee(trainee);
		model.addAttribute("trainee",trainee);
		System.out.println("after trainee");
	   return "Success";
}
	
	@RequestMapping("/DeleteTrainee")
	public String removeTrainee(Model model){
		Trainee trainee=new Trainee();
		model.addAttribute("trainee", trainee);
		return "Delete";
	}
	
	@RequestMapping("/DeleteThis")
	public String getTrainee(Model model,@ModelAttribute("trainee") Trainee trainee){
		Trainee thistrainee=service.getTrainee(trainee.getTraineeId());
		if(thistrainee!=null)
		{
			model.addAttribute("thistrainee",thistrainee);
			return "Delete";
		}
		else
		{
			model.addAttribute("error","cannot delete");
			return "Error";
		}
	}
	@RequestMapping("/DeleteBookPage")
	public String permanentdelete(Model model,@RequestParam("traineeId") int traineeId){
		System.out.println("getting delete");
		service.removeTrainee(traineeId);
		model.addAttribute("successmsg", "Successfully deleted");
		return "Success";
	}
	@RequestMapping("/ModifyTrainee")
	public String ModifyTrainee(Model model){
		Trainee trainee=new Trainee();
		model.addAttribute("trainee", trainee);
		return "Update";
	}
	@RequestMapping("/UpdateThis")
	public String getTrainee1(Model model,@ModelAttribute("trainee") Trainee trainee){
		Trainee thistrainee1=service.getTrainee(trainee.getTraineeId());
		if(thistrainee1!=null)
		{
			model.addAttribute("thistrainee",thistrainee1);
			return "Update";
		}
		else
		{
			model.addAttribute("error","cannot update");
			return "Error";
		}
	}
	
	@RequestMapping("/UpdateBookPage")
	public String updateRecord(Model model,@ModelAttribute("trainee") Trainee trainee){
		service.updateTrainee(trainee);
		model.addAttribute("trainee",trainee);
		model.addAttribute("updateMsg","Book Updated Successfully ");
		return "Success";
	}
	
	@RequestMapping("/RetrieveDetails")
	public String getDetails(Model model){
		List<Trainee> list=service.getDetails();
		model.addAttribute("traineelist",list);
		return "Retrieve";
	}
}
