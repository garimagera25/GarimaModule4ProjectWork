package com.cg.demoonejpa.ui;

	import javax.persistence.EntityManager;
	import javax.persistence.EntityManagerFactory;
	import javax.persistence.Persistence;

	import com.cg.demoonejpa.dto.Employee;
	public class MyMain {

		public static void main(String[] args) {
			
			Employee emp=new Employee();
			emp.setEmpId(1002);
			emp.setEmpName("abd");
			emp.setEmpDepartment("PHP");
			emp.setEmpSalary(1245);
			
			EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("DemoOneJPA");
			EntityManager em=entityManagerFactory.createEntityManager();
			//Insert Data
//			em.getTransaction().begin();
//			em.persist(emp);
//		    em.getTransaction().commit();
//		    em.close();
//		    entityManagerFactory.close();
		    
			//Find
//		    em.getTransaction().begin();
//		    Employee efind=em.find(Employee.class,1002);
//		    em.close();
//		    entityManagerFactory.close();
//		    System.out.println("Id is"+efind.getEmpId());
//		    System.out.println("Name is"+efind.getEmpName());
//		    System.out.println("Salary is"+efind.getEmpSalary());
//		    System.out.println("Dep is"+efind.getEmpDepartment());
			
			//REMOVE
			//Employee eremove=new Employee();
			
//			em.getTransaction().begin();
//			Employee eremove=em.find(Employee.class,1001);
//			em.remove(eremove);
//			em.getTransaction().commit();
//			em.close();
//			entityManagerFactory.close();
			
			
			//UPDATE
			em.getTransaction().begin();
			Employee eupdate=em.find(Employee.class,1002);
			eupdate.setEmpName("varnika");
			eupdate.setEmpSalary(40000);
			eupdate.setEmpDepartment(".NET");
			
			em.merge(eupdate);
			
			em.getTransaction().commit();
			em.close();
			entityManagerFactory.close();
		}
}
