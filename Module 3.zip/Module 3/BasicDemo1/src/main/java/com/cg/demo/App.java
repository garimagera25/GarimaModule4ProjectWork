package com.cg.demo;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Welcome to Capgemini! " );
    }
	public String SayHello()
	{
	return "Vaishali";
	}
}

