package com.cg.demo;

import static org.junit.Assert.assertEquals;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.*;

public class AppTest 
{
	static App app=null;
	@BeforeClass
	public static void beforeClass()
	{
	 app=new App();
	System.out.println(" In Before Class");
	}
	@Test
	public void testSayHello()
	{
	assertEquals("Vaishali",app.SayHello());
	}
}
