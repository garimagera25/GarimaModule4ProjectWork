package com.cg.service;

import java.util.List;

import com.cg.dao.MobileDao;
import com.cg.dao.MobileDaoImpl;
import com.cg.dto.Customers;
import com.cg.dto.RentalPlan;
import com.cg.exception.MobileException;

public class MobileServiceImpl implements MobileService{
	MobileDao mdao=new MobileDaoImpl();
	
	@Override
	public List<RentalPlan> getrentalId() throws MobileException{
		return mdao.getrentalId();
	}

	@Override
	public String insertCustomers(Customers cust) throws MobileException {
		return mdao.insertCustomers(cust);
	}

	@Override
	public RentalPlan getPlan(String rid) throws MobileException {
		return mdao.getPlan(rid);
	}

	
}
