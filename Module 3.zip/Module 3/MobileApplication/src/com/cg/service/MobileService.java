package com.cg.service;

import java.util.List;

import com.cg.dto.Customers;
import com.cg.dto.RentalPlan;
import com.cg.exception.MobileException;

public interface MobileService {

	List<RentalPlan> getrentalId() throws MobileException;
	String insertCustomers(Customers cust) throws MobileException;
	public RentalPlan getPlan(String rid) throws MobileException;
}

