package com.cg.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.Customers;
import com.cg.dto.RentalPlan;
import com.cg.exception.MobileException;
import com.cg.service.MobileService;
import com.cg.service.MobileServiceImpl;


@WebServlet(urlPatterns={"/AddCustomer","/details"})
public class MobileController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public MobileController() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		MobileService mser =new MobileServiceImpl();
		String target = "";
		String url=request.getServletPath();
		switch(url){
		case "/AddCustomer":
		try {
		List<RentalPlan> tlist = mser.getrentalId();
		request.setAttribute("tlist", tlist);
		target="AddCustomer.jsp";
		} catch (MobileException e) {
			String error = e.getMessage();
			request.setAttribute("error",error);
			target="Error.jsp";
		}
		break;
		
		case "/details":
			Customers cust=new Customers();
			String first=request.getParameter("fname");
			String last=request.getParameter("lname");
			String adrs=request.getParameter("Address");
			String mno=request.getParameter("mno");
		    String rid=request.getParameter("RentalId");
			cust.setFirstName(first);
			cust.setLname(last);
			cust.setAddress(adrs);
			cust.setMobileno(mno);
			cust.setRentalid(rid);
				
			try{
				mser.insertCustomers(cust);
				request.setAttribute("cust", cust);
				
				
				RentalPlan plan=mser.getPlan(rid);
				request.setAttribute("plan",plan);
				
				target="ShowDetails.jsp";
			}
			catch (MobileException e) {
				String error = e.getMessage();
				request.setAttribute("error",error);
				target="Error.jsp";
			}
			break;
		}
		RequestDispatcher disp = request.getRequestDispatcher(target);
	    disp.forward(request,response);
	}
}

