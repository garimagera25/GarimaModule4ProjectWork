package com.cg.dto;

public class RentalPlan {

	private String rentalId;
	private int localmin;
	private int stdmin;
	private int smscount;
	private int datamb;
	private int rentalprice;
	
	public int getLocalmin() {
		return localmin;
	}
	public void setLocalmin(int localmin) {
		this.localmin = localmin;
	}
	public int getStdmin() {
		return stdmin;
	}
	public void setStdmin(int stdmin) {
		this.stdmin = stdmin;
	}
	public int getSmscount() {
		return smscount;
	}
	public void setSmscount(int smscount) {
		this.smscount = smscount;
	}
	public int getDatamb() {
		return datamb;
	}
	public void setDatamb(int datamb) {
		this.datamb = datamb;
	}
	public int getRentalprice() {
		return rentalprice;
	}
	public void setRentalprice(int rentalprice) {
		this.rentalprice = rentalprice;
	}
	public String getRentalId() {
		return rentalId;
	}
	public void setRentalId(String rentalId) {
		this.rentalId = rentalId;
	}
	
	
}
