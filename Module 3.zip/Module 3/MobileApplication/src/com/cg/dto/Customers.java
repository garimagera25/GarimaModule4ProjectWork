package com.cg.dto;

public class Customers {

	private String mobileno;
	private String firstName;
	private String lname;
	private String address;
	private String rentalId;
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getRentalid() {
		return rentalId;
	}
	public void setRentalid(String rentalId) {
		this.rentalId = rentalId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	
}
