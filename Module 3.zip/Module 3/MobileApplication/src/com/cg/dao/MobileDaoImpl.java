package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.dto.Customers;
import com.cg.dto.RentalPlan;
import com.cg.exception.MobileException;
import com.cg.dao.DBUtil;

public class MobileDaoImpl implements MobileDao{

	Connection conn;



	@Override
	public List<RentalPlan> getrentalId() throws MobileException {
		List<RentalPlan> tlist = new ArrayList<>();
		conn=DBUtil.getConnection();
		String sql="SELECT rental_id FROM rental_plan";
		
		try {
			PreparedStatement pst= conn.prepareStatement(sql);
			ResultSet rst=pst.executeQuery();
			while(rst.next())
			{
				RentalPlan plan = new RentalPlan();
				plan.setRentalId(rst.getString(1));
				tlist.add(plan);
			} 
		} catch (SQLException e) {
			throw new MobileException("Problem in fetching list");
		}
	  return tlist;
			}



	@Override
	public String insertCustomers(Customers cust) throws MobileException {
		conn=DBUtil.getConnection();
       String sql="INSERT INTO customers VALUES(?,?,?,?,?)";
		
		
		int ct=0;
		try{conn=DBUtil.getConnection();
			System.out.println("in dao");
			System.out.println("enter");
			PreparedStatement pst= conn.prepareStatement(sql);
			pst.setString(1,cust.getMobileno());
			pst.setString(2,cust.getFirstName());
			pst.setString(3,cust.getLname());
			pst.setString(4,cust.getAddress());
			pst.setString(5,cust.getRentalid());
			ct=pst.executeUpdate();
			System.out.println(cust.getRentalid());
			
		} catch(SQLException e) {
			throw new MobileException("Problem in inserting data ");
		}
			return cust.getRentalid();
		}



	@Override
	public RentalPlan getPlan(String rid) throws MobileException {
		String sql="Select rental_id,local_min,std_min,sms_count,data_mb FROM rental_plan WHERE rental_id=?";
		RentalPlan plan=null;
		conn=DBUtil.getConnection();
		try {
		PreparedStatement pst= conn.prepareStatement(sql);
		pst.setString(1,rid);
		ResultSet rst=pst.executeQuery();
		
		if(rst.next()){
			plan=new RentalPlan();
			plan.setRentalId(rst.getString(1));
			plan.setLocalmin(rst.getInt(2));
			plan.setStdmin(rst.getInt(3));
			plan.setSmscount(rst.getInt(4));
			plan.setDatamb(rst.getInt(5));
		}
	} catch(SQLException e) {
		throw new MobileException("Problem in fetching mobile data ");
	}
		return plan;
	}

		
}


