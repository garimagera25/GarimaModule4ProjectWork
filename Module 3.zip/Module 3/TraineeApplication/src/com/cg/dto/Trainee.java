package com.cg.dto;

public class Trainee {

	private int traineeid;
	private String traineeName;
	private String traineeDomain;
	private String traineeloc;
	public int getTraineeid() {
		return traineeid;
	}
	public void setTraineeid(int traineeid) {
		this.traineeid = traineeid;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	public String getTraineeloc() {
		return traineeloc;
	}
	public void setTraineeloc(String traineeloc) {
		this.traineeloc = traineeloc;
	}
	
	
}
