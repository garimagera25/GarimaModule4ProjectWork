package com.cg.service;

import com.cg.dao.TraineeDao;
import com.cg.dao.TraineeDaoImpl;
import com.cg.dto.Trainee;
import com.cg.exception.TraineeException;

public class TraineeServiceImpl implements TraineeService{
	TraineeDao tdao = new TraineeDaoImpl();
	
	@Override
	public Trainee getdetails(int tid) throws TraineeException {
		return tdao.getdetails(tid);
	}

	@Override
	public int insertTraineeDetail(Trainee trainee) throws TraineeException {
		return tdao.insertTraineeDetail(trainee);
	}

	@Override
	public void deleteTrainee(int mid) throws TraineeException  {
	}

	@Override
	public void updateTrainees(Trainee trainee1) throws TraineeException {
		tdao.updateTrainees(trainee1);
	}

}
