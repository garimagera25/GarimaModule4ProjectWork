package com.cg.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.Trainee;
import com.cg.service.TraineeService;
import com.cg.service.TraineeServiceImpl;

@WebServlet(urlPatterns={"/Retrieve","/Delete","/Update"})
public class TraineeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public TraineeServlet() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		TraineeService tser = (TraineeService) new TraineeServiceImpl();
		String target = "";
		String url=request.getServletPath();
		switch(url){
		case "/Retrieve":
			String midStr=request.getParameter("tid");
			try{
				System.out.println("in dao");
			    Trainee trainee = tser.getdetails(Integer.parseInt(midStr));
			    System.out.println("in main");
			    request.setAttribute("trainee", trainee);
			    target="List.jsp";
			} catch(Exception e) {
				String error=e.getMessage();
				request.setAttribute("error", error);
				target="Error.jsp";
			}
			break;
			
		case "/Delete":
			String midStr1=request.getParameter("mid");
			try{
				System.out.println("in dao");
			    int mid = Integer.parseInt(midStr1);
			    tser.deleteTrainee(mid);
			    System.out.println("in main");
			    request.setAttribute("trainee1", mid);
			    target="Remove.jsp";
			} catch(Exception e) {
				String error=e.getMessage();
				request.setAttribute("error", error);
				target="Error.jsp";
			}
			break;	
			
		case "/Update":
			   Trainee trainee1 =new Trainee();
			   int trid=Integer.parseInt(request.getParameter("uid"));
			   String trname=request.getParameter("tname");
			   String trdom=request.getParameter("tdom");
			   String trloc=request.getParameter("tloc");
			   trainee1.setTraineeid(trid);
			   trainee1.setTraineeName(trname);
			   trainee1.setTraineeDomain(trdom);
			   trainee1.setTraineeloc(trloc);
			try{
				System.out.println("in hp");
			    tser.updateTrainees(trainee1);
			    request.setAttribute("trainee1", trainee1);
			    target="Data.jsp";
			    
			} catch(Exception e) {
				String error=e.getMessage();
				request.setAttribute("error", error);
				target="Error.jsp";
			}
			break;
}
		
		RequestDispatcher disp = request.getRequestDispatcher(target);
	    disp.forward(request,response);
	}
}
