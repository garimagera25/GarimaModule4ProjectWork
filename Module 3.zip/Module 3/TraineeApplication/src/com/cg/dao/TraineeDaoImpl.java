package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.dto.Trainee;
import com.cg.exception.TraineeException;

public class TraineeDaoImpl implements TraineeDao{
	Connection conn;
	
	@Override
	public Trainee getdetails(int tid) throws TraineeException {
		String sql="Select Trainee_id from Trainee WHERE Trainee_id=?";
		Trainee trainee=null;
		conn=DBUtil.getConnection();
		try {
			System.out.println("in dao");
		PreparedStatement pst= conn.prepareStatement(sql);
		pst.setInt(1,tid);
		ResultSet rst=pst.executeQuery();
		System.out.println("after execution");
		if(rst.next()){
			trainee = new Trainee();
			trainee.setTraineeid(rst.getInt("Trainee_id"));
		}
	} catch(SQLException e) {
		throw new TraineeException("Problem in fetching mobile data ");
	}
		return trainee;
	}

	@Override
	public int insertTraineeDetail(Trainee trainee) throws TraineeException {
		String sql="INSERT INTO Trainee VALUES(?,?,?,?)";
		int ct=0;
		try{
			conn=DBUtil.getConnection();
			PreparedStatement pst= conn.prepareStatement(sql);
			pst.setInt(1,trainee.getTraineeid());
			pst.setString(2,trainee.getTraineeName());
			pst.setString(3,trainee.getTraineeDomain());
			pst.setString(4,trainee.getTraineeloc());
			ct=pst.executeUpdate();
			
		} catch(SQLException e) {
			throw new TraineeException("Problem in inserting data ");
		}
			return trainee.getTraineeid();
		}

	@Override
	public void deleteTrainee(int mid) throws TraineeException {
		String delqry="Delete from Trainee WHERE Trainee_id=?";
		conn=DBUtil.getConnection();
		try {
		PreparedStatement pst= conn.prepareStatement(delqry);
		pst.setInt(1,mid);
		pst.executeUpdate();
		
	} catch(SQLException e) {
		throw new TraineeException("Problem in fetching mobile data ");
	}
}

	@Override
	public void updateTrainees(Trainee trainee1) throws TraineeException {
		String updateQry="UPDATE TRAINEE set Trainee_Name=?,Trainee_Domain=?,Trainee_Location=? where Trainee_id=?";
		conn=DBUtil.getConnection();
		try{
			System.out.println("in dao");
			conn=DBUtil.getConnection();
			PreparedStatement pst= conn.prepareStatement(updateQry);
			System.out.println("bank");
		
			pst.setString(1,trainee1.getTraineeName());
			pst.setString(2,trainee1.getTraineeDomain());
			pst.setString(3,trainee1.getTraineeloc());
			pst.setInt(4,trainee1.getTraineeid());
			pst.executeUpdate();
			System.out.println("in class");
			
		} catch(SQLException e) {
			throw new TraineeException("Problem in inserting data ");
		}
}
}
