package com.cg.demos;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
@MultipartConfig(location="d:/Demos")

@WebServlet("/MultiPartServlet")
public class MultiPartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uname=request.getParameter("uname");
		Part photo = request.getPart("photo");
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		out.print(uname+",your photo uploaded successfully..");
		photo.write(uname+".jpg");
		Collection<String> headers = photo.getHeaderNames();
		for(String str:headers){
			out.print("<br/>"+str+":"+photo.getHeader(str));
		}
	}

}
