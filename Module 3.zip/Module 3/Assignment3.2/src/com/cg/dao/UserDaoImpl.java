package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.dto.User;
import com.cg.exception.UserException;


public class UserDaoImpl implements UserDao {
	Connection conn;

	@Override
	public int insertEmp(User user) throws UserException {
		String sql="INSERT INTO RegisteredUsers VALUES(?,?,?,?,?,?)";
		int ct=0;
		try {
			System.out.println("in dao");
			conn = DBUtil.getConnection();
		
    	
    	PreparedStatement pst=conn.prepareStatement(sql);
    	System.out.println("in prepare");
    	pst.setString(1,user.getFirstname());
    	pst.setString(2,user.getLastname());
    	pst.setString(3,user.getPassword());
    	pst.setString(4,user.getGender());
    	pst.setString(5,user.getSkill());
    	pst.setString(6,user.getCity());
    	System.out.println("setting");
    	ct=pst.executeUpdate();
    	System.out.println("execute query");
    } catch (SQLException e) {
    	throw new UserException("Problem in inserting record "+e.getMessage());
    }
    return ct;
	}
}
