package com.cg.service;

import com.cg.dao.UserDao;
import com.cg.dao.UserDaoImpl;
import com.cg.dto.User;
import com.cg.exception.UserException;

public class UserServiceImpl implements UserService {
	UserDao udao= new UserDaoImpl();
	
	
	public UserServiceImpl(){
		
	}
			@Override
			public int registerUser(User user)throws UserException {
				return udao.insertEmp(user);
			}

	}
	