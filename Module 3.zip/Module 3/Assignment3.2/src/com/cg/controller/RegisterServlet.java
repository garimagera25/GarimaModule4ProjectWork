package com.cg.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.User;
import com.cg.exception.UserException;
import com.cg.service.UserService;
import com.cg.service.UserServiceImpl;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("in register");
		UserService ser = new UserServiceImpl();
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String pwd=request.getParameter("pwd");
		String gender=request.getParameter("gender");
		String[] skill=request.getParameterValues("skill");
		String skillset=String.join(" ,", skill);
		String city=request.getParameter("city");
	
	    User user=new User();
	    user.setFirstname(fname);
	    user.setLastname(lname);
	    user.setPassword(pwd);
	    user.setGender(gender);
	    user.setSkill(skillset);
	    user.setCity(city);
	
	   String target="";
	
	try {
		
		ser.registerUser(user);
		request.setAttribute("use",user);
		target="success";
	} catch (UserException e) {
		request.setAttribute("message", e.getMessage());
		target="failure";
	}
	RequestDispatcher disp=request.getRequestDispatcher(target);
	disp.forward(request, response);
	
}
	

	}
