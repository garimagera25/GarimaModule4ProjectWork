package com.cg.service;

import java.util.List;

import com.cg.dto.Trainee;
import com.cg.exception.TraineeException;

public interface TraineeService {

	int insertTraineeDetail(Trainee trainee) throws TraineeException; 
	List<Trainee> getAllTrainees() throws TraineeException;
}
