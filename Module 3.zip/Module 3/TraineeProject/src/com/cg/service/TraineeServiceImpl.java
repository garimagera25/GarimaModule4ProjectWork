package com.cg.service;

import java.util.List;

import com.cg.dao.TraineeDao;
import com.cg.dao.TraineeDaoImpl;
import com.cg.dto.Trainee;
import com.cg.exception.TraineeException;

public class TraineeServiceImpl implements TraineeService{
	TraineeDao tdao = new TraineeDaoImpl();

	@Override
	public int insertTraineeDetail(Trainee trainee) throws TraineeException {
		return tdao.insertTraineeDetail(trainee);
	}

	@Override
	public List<Trainee> getAllTrainees() throws TraineeException {
		return tdao.getAllTrainees();
	}

}
