package com.cg.dto;

public class Trainee {

	private int tid;
	private String tname;
	private String tdomain;
	private String tloc;
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public String getTdomain() {
		return tdomain;
	}
	public void setTdomain(String tdomain) {
		this.tdomain = tdomain;
	}
	public String getTloc() {
		return tloc;
	}
	public void setTloc(String tloc) {
		this.tloc = tloc;
	}
	
	
}
