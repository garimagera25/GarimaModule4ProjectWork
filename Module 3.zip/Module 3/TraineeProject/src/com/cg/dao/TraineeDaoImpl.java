package com.cg.dao;

import java.util.List;

import com.cg.dto.Trainee;
import com.cg.exception.TraineeException;

public class TraineeDaoImpl implements TraineeDao {

	@Override
	public int insertTraineeDetail(Trainee trainee) throws TraineeException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Trainee> getAllTrainees() throws TraineeException {
		// TODO Auto-generated method stub
		return null;
	}

}
