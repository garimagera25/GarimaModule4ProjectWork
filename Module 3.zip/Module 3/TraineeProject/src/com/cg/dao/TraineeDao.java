package com.cg.dao;

import java.util.List;


import com.cg.dto.Trainee;
import com.cg.exception.TraineeException;

public interface TraineeDao {

	int insertTraineeDetail(Trainee trainee) throws TraineeException; 
	List<Trainee> getAllTrainees() throws TraineeException;
}
