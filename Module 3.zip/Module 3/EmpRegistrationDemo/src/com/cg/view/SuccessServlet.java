package com.cg.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.Employee;

@WebServlet("/success")
public class SuccessServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Employee emp=(Employee) request.getAttribute("emp");
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		out.print("<h1>Thanks for Registration</h1>");
		out.print("<h2>Registred with below details</h2>");
		out.print("<h3>Empno :"+emp.getEmpno()+"</h3>");
		out.print("<h3>EmpName :"+emp.getEname()+"</h3>");
		out.print("<h3>DeptNo :"+emp.getDeptno()+"</h3>");
		out.print("<h3>Salary :"+emp.getSal()+"</h3>");
		out.print("<a href='index.html'>Home</a>");
	}

}
