package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.dto.Employee;
import com.cg.exceptions.EmpException;

public class EmpDaoImpl implements EmpDao {
     Connection conn;
     
    @Override
    public int insertEmp(Employee emp) throws EmpException {
    	String sql="INSERT INTO emp(empno,ename,sal,deptno) "
    			+ "VALUES(?,?,?,?)";
    	int ct=0;
    	conn=DBUtil.getConnection();
    	try {
    	PreparedStatement pst=conn.prepareStatement(sql);
    	pst.setInt(1,emp.getEmpno());
    	pst.setString(2,emp.getEname());
    	pst.setDouble(3,emp.getSal());
    	pst.setInt(4,emp.getDeptno());
    	ct=pst.executeUpdate();
    } catch (SQLException e) {
    	throw new EmpException("Problem in inserting record "+e.getMessage());
    }
    return ct;
}
}
