package com.cg.dao;

import com.cg.dto.Employee;
import com.cg.exceptions.EmpException;

public interface EmpDao {

	int insertEmp(Employee emp) throws EmpException;
}
