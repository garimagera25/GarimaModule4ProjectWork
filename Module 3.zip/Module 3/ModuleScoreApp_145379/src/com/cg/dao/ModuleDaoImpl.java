package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;

import com.cg.dto.Assessment;
import com.cg.dto.TraineeBean;
import com.cg.exception.ModuleScoreException;

public class ModuleDaoImpl implements ModuleDao {
	
	Connection conn;



	@Override
	public List<TraineeBean> getTraineeId() throws ModuleScoreException {
		List<TraineeBean> tlist = new ArrayList<>();
		conn=DBUtil.getConnection();
		String sql="SELECT trainee_id,trainee_name FROM trainees";
		
		try {
			PreparedStatement pst= conn.prepareStatement(sql);
			ResultSet rst=pst.executeQuery();
			while(rst.next())
			{
				TraineeBean trainee = new TraineeBean();
				trainee.setTraineeid(rst.getInt(1));
				trainee.setTraineeName(rst.getString(2));
				tlist.add(trainee);
			} 
		} catch (SQLException e) {
			throw new ModuleScoreException("Problem in fetching list");
		}
	  return tlist;
			}
		

	@Override
	public long insertAssessment(Assessment assg) throws ModuleScoreException {
		String sql="INSERT INTO AssessmentScore VALUES(?,?,?,?,?,?,?)";
		
		
		int ct=0;
		try{
			conn=DBUtil.getConnection();
			PreparedStatement pst= conn.prepareStatement(sql);
			pst.setLong(1,assg.getTraineeid());
			pst.setString(2,assg.getModuleName());
			pst.setInt(3,assg.getMpt());
			pst.setInt(4,assg.getMtt());
			pst.setInt(5,assg.getMarks());
			pst.setInt(6,assg.getTotalNo());
			pst.setInt(7,assg.getGrade());
			ct=pst.executeUpdate();
			
		} catch(SQLException e) {
			throw new ModuleScoreException("Problem in inserting data ");
		}
			return assg.getTraineeid();
		}
	}

	

