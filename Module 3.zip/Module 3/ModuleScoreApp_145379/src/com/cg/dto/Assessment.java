package com.cg.dto;

public class Assessment {

	private long traineeid;
	private String moduleName;
	private int mpt;
	private int mtt;
	private int marks;
	private int totalNo;
	private int grade;
	

	
	

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

	@Override
	public String toString() {
		return "Assessment [traineeid=" + traineeid + ", moduleName="
				+ moduleName + ", mpt=" + mpt + ", mtt=" + mtt + ", marks="
				+ marks + ", totalNo=" + totalNo + ", grade=" + grade + "]";
	}

	public long getTraineeid() {
		return traineeid;
	}

	public void setTraineeid(long traineeid) {
		this.traineeid = traineeid;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public int getMpt() {
		return mpt;
	}

	public void setMpt(int mpt) {
		this.mpt = mpt;
	}

	public int getMtt() {
		return mtt;
	}

	public void setMtt(int mtt) {
		this.mtt = mtt;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	public int getTotalNo() {
		return totalNo;
	}

	public void setTotalNo(int totalNo) {
		this.totalNo = totalNo;
	}

	
	
	
}
