package com.cg.dto;

public class TraineeBean {

	private int traineeid;
	private String traineeName;
	
	public TraineeBean() {
		
	}
	

	public TraineeBean(int traineeid, String traineeName) {
		super();
		this.traineeid = traineeid;
		this.traineeName = traineeName;
	}


	public int getTraineeid() {
		return traineeid;
	}

	public void setTraineeid(int traineeid) {
		this.traineeid = traineeid;
	}

	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}


	@Override
	public String toString() {
		return "TraineeBean [traineeid=" + traineeid + ", traineeName="
				+ traineeName + "]";
	}

	
	
}
