package com.cg.exception;

public class ModuleScoreException extends Exception {


	public ModuleScoreException() {
	}

	public ModuleScoreException(String message) {
		super(message);
	}

	public ModuleScoreException(Throwable cause) {
		super(cause);
	}

	public ModuleScoreException(String message, Throwable cause) {
		super(message, cause);
	}

	public ModuleScoreException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
