package com.cg.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ScoreController
 */
@WebServlet(urlPatterns={"redirect","/ModuleScore"})
public class ScoreController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public ScoreController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ModuleService mser = (ModuleService) new ModuleServiceImpl();
		Assessment aDetails=new Assessment();
		String target = "";
		String url=request.getServletPath();
		switch(url){
		case "/redirect":
		try {
		List<TraineeBean> tlist = mser.getTraineeId();
		request.setAttribute("tlist", tlist);
		target="AddAssessment.jsp";
		} catch (ModuleScoreException e) {
			String error = e.getMessage();
			request.setAttribute("error",error);
			target="Error.jsp";
		}
		break;
		
		case "/ModuleScore":
			int grade=0;
			String traineeid=request.getParameter("traineeid");
			long tid=Long.parseLong(traineeid);
			
			String modulename=request.getParameter("module");
			
			String mpt_String=request.getParameter("mpt");
			int mpt=Integer.parseInt(mpt_String);
					
			String mtt_String=request.getParameter("mpt");
			int mtt=Integer.parseInt(mtt_String);
			
			String assg=request.getParameter("assg");
			int assignment=Integer.parseInt(assg);
			
			aDetails.setTraineeid(tid);
			aDetails.setModuleName(modulename);
			aDetails.setMpt(mpt);
			aDetails.setMtt(mtt);
			aDetails.setMarks(assignment);
			int total=mpt+mtt+assignment;
			aDetails.setTotalNo(total);
			if((total>0) && (total<=49))
			grade=0;
			else if((total>49) && (total <=59))
			grade=1;
			else if((total>59) && (total <=69))
			grade=2;
			else if((total>69) && (total <=79))
			grade=3;
			else if((total>79) && (total <=89))
			grade=4;
			else if((total>89) && (total <=100))
			grade=5;
			aDetails.setGrade(grade);
			
			try{
				mser.insertAssessment(aDetails);
				request.setAttribute("aDetails", aDetails);
				target="final.jsp";
			}
			catch (ModuleScoreException e) {
				String error = e.getMessage();
				request.setAttribute("error",error);
				target="Error.jsp";
			}
			break;
	}
		RequestDispatcher disp = request.getRequestDispatcher(target);
	    disp.forward(request,response);
	}
	}
