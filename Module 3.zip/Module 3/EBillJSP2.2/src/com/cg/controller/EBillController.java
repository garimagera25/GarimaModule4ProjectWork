package com.cg.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.exception.BillException;
import com.cg.dto.Bill;
import com.cg.dto.Consumer;
import com.cg.service.BillService;
import com.cg.service.BillServiceImpl;

/**
 * Servlet implementation class EBillController
 */
@WebServlet(urlPatterns={"/list","/search","/details","/generatebill"})
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    
    public EBillController() {
        super();
    }
    private double calculateBill(double lread, double meterread) {
		double netamt=0;
		double unitcon=meterread-lread;
		int fixedcharge=100;
		double r=1.15;
		netamt=unitcon * r + fixedcharge;
		return netamt;
		
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BillService mser = (BillService) new BillServiceImpl();
		String target = "";
		String url=request.getServletPath();
		switch(url){
		case "/list":
		try {
		List<Consumer> clist = mser.getAllConsumers();
		request.setAttribute("clist", clist);
		target="ShowConsumerList.jsp";
		} catch (BillException e) {
			String error = e.getMessage();
			request.setAttribute("error",error);
			target="Error.jsp";
		}
		break;
		
		case "/search":
			
				int cno=Integer.parseInt(request.getParameter("cno"));
				HttpSession session=request.getSession(true);
				session.setAttribute("consumerno", cno);
				try{
				Consumer cons = mser.SearchConsumers(cno);
				request.setAttribute("cons", cons);
				
				target = "ShowConsumer.jsp";
				} catch(Exception e) {
					String error=e.getMessage();
					request.setAttribute("error", error);
					target="Error.jsp";
				}
				break;
				
				
		case "/details":
			String cnostr=request.getParameter("cno");
			     int id=Integer.parseInt(cnostr);
			try {
				System.out.println("details");
				List<Bill> blist = mser.getAllBillDetails(id);
				request.setAttribute("blist", blist);
				HttpSession session2=request.getSession(true);
				session2.setAttribute("co", cnostr);
				target="ShowBills.jsp";
				} catch (NumberFormatException e) {
					e.printStackTrace();
				}
			catch (BillException e) {
					String error = e.getMessage();
					request.setAttribute("error",error);
					target="Error.jsp";
				}
				break;
				
		case "/generatebill":
			int consno=Integer.parseInt(request.getParameter("cnumber"));
			double lread=Double.valueOf(request.getParameter("lmnth"));
			double meterread=Double.valueOf(request.getParameter("cmnth"));
			double unitcon=meterread-lread;
			double netamt;
			 HttpSession session1=request.getSession(true);
			 session1.setAttribute("cono", consno);
			
			
			 try {
				 if(meterread>lread)
				 {
					 
					 netamt=calculateBill(lread,meterread);
					 Bill bill=new Bill(consno,meterread,unitcon,netamt);
					 request.setAttribute("bill", bill);
	                  mser.insertBillDetail(bill);
					 target="CalculateBill.jsp";
					 
				 }
				 else
				 {
					 throw new BillException("Current reading cannnot be less than last reading");
				 }
			 } catch (BillException e) {
				 request.setAttribute("error", e.getMessage());
				 target="Error.jsp";
			 }
			 break;
		}
		 RequestDispatcher disp = request.getRequestDispatcher(target);
		    disp.forward(request,response);
}
}
	

