package com.cg.service;

import java.util.List;

import com.cg.dao.BillDaoImpl;
import com.cg.dao.BillDao;
import com.cg.dto.Bill;
import com.cg.dto.Consumer;
import com.cg.exception.BillException;
import com.cg.service.BillServiceImpl;


	public class BillServiceImpl implements BillService {
		  BillDao mdao = new BillDaoImpl();

		@Override
		public List<Consumer> getAllConsumers() throws BillException {
			return mdao.getAllConsumers();
		}

		@Override
		public Consumer getdetails(int cno) throws BillException {
			return mdao.getdetails(cno);
		}

		@Override
		public Consumer SearchConsumers(int cn) throws BillException {
			return mdao.SearchConsumers(cn);
		}

		@Override
		public List<Bill> getAllBillDetails(int bid) throws BillException {
			return mdao.getAllBillDetails( bid);
		}

		@Override
		public int insertBillDetail(Bill bill) throws BillException {
			return mdao.insertBillDetail(bill);
		}
	}
