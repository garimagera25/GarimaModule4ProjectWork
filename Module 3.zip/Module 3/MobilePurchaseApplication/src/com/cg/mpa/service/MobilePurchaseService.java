package com.cg.mpa.service;

import java.util.List;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetail;
import com.cg.mpa.exceptions.MobileException;

public interface MobilePurchaseService {
	 public List<Mobile> getAllMobiles() throws MobileException;
	 Mobile getMobile(int mid) throws MobileException;
	 int insertPurchaseDetails(PurchaseDetail pDetail) throws MobileException;
}
