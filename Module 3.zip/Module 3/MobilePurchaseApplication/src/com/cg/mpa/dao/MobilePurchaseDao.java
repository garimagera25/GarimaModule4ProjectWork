package com.cg.mpa.dao;

import java.util.List;

import com.cg.mpa.exceptions.MobileException;
import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetail;
	
	public interface MobilePurchaseDao {
	List<Mobile> getAllMobiles() throws MobileException;
	int insertPurchaseDetail(PurchaseDetail pDetails) throws MobileException;
	
	Mobile getMobile(int mid) throws MobileException;
	int updateMobileQuantity(int mid) throws MobileException;
	}
