package com.cg.mpa.dto;

import java.time.LocalDate;

public class PurchaseDetail {

private int purchaseid;
private String custName;
private String mailid;
private String phoneno;
private LocalDate purchaseDate;
private int mobileid;
public PurchaseDetail() {
	
}
public int getPurchaseid() {
	return purchaseid;
}
public void setPurchaseid(int purchaseid) {
	this.purchaseid = purchaseid;
}
public String getCustName() {
	return custName;
}
public void setCustName(String custName) {
	this.custName = custName;
}
public String getMailid() {
	return mailid;
}
public void setMailid(String mailid) {
	this.mailid = mailid;
}
public String getPhoneno() {
	return phoneno;
}
public void setPhoneno(String phoneno) {
	this.phoneno = phoneno;
}
public LocalDate getPurchaseDate() {
	return purchaseDate;
}
public void setPurchaseDate(LocalDate purchaseDate) {
	this.purchaseDate = purchaseDate;
}
public int getMobileid() {
	return mobileid;
}
public void setMobileid(int mobileid) {
	this.mobileid = mobileid;
}
@Override
public String toString() {
	return "PurchaseDetail [purchaseid=" + purchaseid + ", custName="
			+ custName + ", mailid=" + mailid + ", phoneno=" + phoneno
			+ ", purchaseDate=" + purchaseDate + ", mobileid=" + mobileid + "]";
}



}
