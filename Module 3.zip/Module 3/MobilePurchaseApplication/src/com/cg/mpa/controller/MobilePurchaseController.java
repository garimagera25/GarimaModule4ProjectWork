package com.cg.mpa.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.PurchaseDetail;
import com.cg.mpa.exceptions.MobileException;
import com.cg.mpa.service.MobilePurchaseService;
import com.cg.mpa.service.MobilePurchaseServiceImpl;

/**
 * Servlet implementation class MobilePurchaseController
 */
@WebServlet(urlPatterns={"/home","/buy","/purchase"})
public class MobilePurchaseController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public MobilePurchaseController(){
		super();
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	MobilePurchaseService mser = new MobilePurchaseServiceImpl();
	String target = "";
	String url=request.getServletPath();
	switch(url){
	case "/home":
	try {
	List<Mobile> mlist = mser.getAllMobiles();
	request.setAttribute("mlist", mlist);
	target="Home.jsp";
	} catch (MobileException e) {
		String error = e.getMessage();
		request.setAttribute("error",error);
		target="Error.jsp";
	}
	break;
	case "/buy":
		String midStr=request.getParameter("mid");
		try{
		Mobile mobile = mser.getMobile(Integer.parseInt(midStr));
		HttpSession sess=request.getSession(true);
		sess.setAttribute("mobile", mobile);
		target = "insert.jsp";
		} catch(Exception e) {
			String error=e.getMessage();
			request.setAttribute("error", error);
			target="Error.jsp";
		}
		break;
	case "/purchase":
		String cname=request.getParameter("cname");
		String mailid=request.getParameter("mailid");
		String phoneno=request.getParameter("phoneno");
		String dateStr = request.getParameter("pdate");
		DateTimeFormatter format= DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate pdate=LocalDate.parse(dateStr,format);
		PurchaseDetail pdetail=new PurchaseDetail();
		pdetail.setCustName(cname);
		pdetail.setMailid(mailid);
		pdetail.setPhoneno(phoneno);
		pdetail.setPurchaseDate(pdate);
		HttpSession sess=request.getSession(false);
		Mobile mobile =(Mobile)sess.getAttribute("mobile");
		pdetail.setMobileid(mobile.getMobileid());
		try {
			mser.insertPurchaseDetails(pdetail);
			request.setAttribute("pdetails", pdetail);
			target="Success.jsp";
		} catch(MobileException e) {
			String error = e.getMessage();
			request.setAttribute("error",error);
			target="Error.jsp";
		}
		break;
	}
	RequestDispatcher disp = request.getRequestDispatcher(target);
    disp.forward(request,response);
}
}