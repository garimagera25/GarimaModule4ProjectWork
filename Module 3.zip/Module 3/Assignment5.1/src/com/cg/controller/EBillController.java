package com.cg.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.Bill;
import com.cg.exception.EBillException;
import com.cg.service.EBillService;
import com.cg.service.EBillServiceImpl;

@WebServlet("/generatebill")
public class EBillController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}
	 private double calculateBill(double lread, double meterread) {
			double netamt=0;
			double unitcon=meterread-lread;
			int fixedcharge=100;
			double r=1.15;
			netamt=unitcon * r + fixedcharge;
			return netamt;
			
		}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		EBillService mser = (EBillService) new EBillServiceImpl();
		String target = "";
		String url=request.getServletPath();
		
		int consno=Integer.parseInt(request.getParameter("cnumber"));
		double lread=Double.valueOf(request.getParameter("lmnth"));
		double meterread=Double.valueOf(request.getParameter("cmnth"));
		double unitcon=meterread-lread;
		double netamt;
		 HttpSession session1=request.getSession(true);
		 session1.setAttribute("cono", consno);
		
		
		 try {
			 if(meterread>lread)
			 {
				 
				 netamt=calculateBill(lread,meterread);
				 Bill bill=new Bill(consno,meterread,unitcon,netamt);
				 request.setAttribute("bill", bill);
                 mser.insertBillDetail(bill);
				 target="CalculateBill.jsp";
				 
			 }
			 else
			 {
				 throw new EBillException("Current reading cannnot be less than last reading");
			 }
		 } catch (EBillException e) {
			 request.setAttribute("error", e.getMessage());
			 target="Error.jsp";
		 }
	 RequestDispatcher disp = request.getRequestDispatcher(target);
	    disp.forward(request,response);
		}
	}
