package com.cg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import com.cg.dto.Bill;
import com.cg.dto.Consumer;
import com.cg.exception.EBillException;

public class BillDaoImpl implements BillDao{
Connection conn;
	
	
	
	public Consumer getdetails(int cno) throws EBillException {
		String sql="Select CONSUMER_NUM FROM CONSUMERS WHERE CONSUMER_NUM=?";
		Consumer Consumers=null;
		conn=DBUtil.getConnection();
		try {
		PreparedStatement pst= conn.prepareStatement(sql);
		pst.setInt(1,cno);
		ResultSet rst=pst.executeQuery();
		
		if(rst.next()){
			Consumer Consumer = new Consumer();
			Consumer.setConsno(rst.getInt("CONSUMER_NUM"));
		}
	} catch(SQLException e) {
		throw new EBillException("Problem in fetching mobile data ");
	}
		return Consumers;
	}



	@Override
	public int insertBillDetail(Bill bill) throws EBillException {
int r=0;
		
		String insqry = "Insert into BillDetails (bill_num,consumer_num,cur_reading,unitConsumed,netAmount,bill_date) values (seq_bill_num.nextval ,?,?,?,?,?)";
		int billNum=0;
		
		
		try {
		conn = DBUtil.getConnection();
		PreparedStatement pst= conn.prepareStatement(insqry);
		
		     pst.setInt(1,bill.getConsno());
			 pst.setDouble(2, bill.getMeterread());
			 pst.setDouble(3,bill.getUnitcon());
			 pst.setDouble(4,bill.getNetamt());
			 LocalDate billdate=LocalDate.now();
			 pst.setDate(5,Date.valueOf(billdate));
			 
			 r=pst.executeUpdate();
			 
			 if(r==1){
				 Statement st=conn.createStatement();
				 ResultSet rs=st.executeQuery("select seq_bill_num.currval from dual");
				 if(rs.next())
					 billNum=rs.getInt(1);
				 else
					 
		throw new EBillException("Consumer no does not exist");
	}
		} catch (SQLException e) {
			
			throw new EBillException("Consumer Id" +bill.getConsno() +"does not exist");
		}
  return billNum;
}	
		
	
}
