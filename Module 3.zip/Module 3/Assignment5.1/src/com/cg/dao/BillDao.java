package com.cg.dao;

import com.cg.dto.Bill;
import com.cg.dto.Consumer;
import com.cg.exception.EBillException;

public interface BillDao {
	int insertBillDetail(Bill bill) throws EBillException;
	Consumer getdetails(int cno) throws EBillException;
}
