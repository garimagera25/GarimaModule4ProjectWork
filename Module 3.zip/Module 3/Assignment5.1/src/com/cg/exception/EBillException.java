package com.cg.exception;

public class EBillException extends Exception {

	public EBillException() {
	}

	public EBillException(String message) {
		super(message);
	}

	public EBillException(Throwable cause) {
		super(cause);
	}

	public EBillException(String message, Throwable cause) {
		super(message, cause);
	}

	public EBillException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}


}
