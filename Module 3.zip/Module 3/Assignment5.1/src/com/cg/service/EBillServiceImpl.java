package com.cg.service;

import com.cg.dao.BillDao;
import com.cg.dao.BillDaoImpl;
import com.cg.dto.Bill;
import com.cg.dto.Consumer;
import com.cg.exception.EBillException;

public class EBillServiceImpl implements EBillService {
	BillDao mdao = new BillDaoImpl();

	@Override
	public Consumer getdetails(int cno) throws EBillException {
		return mdao.getdetails(cno);
	}

	@Override
	public int insertBillDetail(Bill bill) throws EBillException {
		return mdao.insertBillDetail(bill);
	}

}
