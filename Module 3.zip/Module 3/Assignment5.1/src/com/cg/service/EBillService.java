package com.cg.service;

import com.cg.dto.Bill;
import com.cg.dto.Consumer;
import com.cg.exception.EBillException;

public interface EBillService {

	Consumer getdetails(int cno) throws EBillException;
	int insertBillDetail(Bill bill) throws EBillException;
}
