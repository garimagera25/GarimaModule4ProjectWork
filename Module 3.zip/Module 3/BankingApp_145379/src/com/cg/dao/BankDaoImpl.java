package com.cg.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.dto.AccountBean;
import com.cg.dto.TransactionBean;
import com.cg.exception.BankException;
import com.cg.dao.DBUtil;

public class BankDaoImpl implements IBankDao{

	Connection conn;
	   
	@Override
	public List<AccountBean> getAccountDetails(String cname) throws BankException{
		String sql="Select * from account_details WHERE customer_name=?";
		conn=DBUtil.getConnection();
		List<AccountBean> blist=new ArrayList<>();
		try {
		PreparedStatement pst= conn.prepareStatement(sql);
		pst.setString(1,cname);
		ResultSet rst=pst.executeQuery();
		while(rst.next()){
			System.out.println("indao");
			AccountBean account=new AccountBean();
			account.setAccountNo(rst.getString("account_number"));
			account.setAccountLocation(rst.getString("account_location"));
			account.setAccountType(rst.getString("account_type"));
			account.setBalance(rst.getDouble("balance"));
			account.setCustomerName(rst.getString("customer_name"));
			blist.add(account);
		}
		return blist;
	} catch(SQLException e) {
		throw new BankException("Problem in fetching mobile data ");
	}
	}

	@Override
	public int addTransaction(TransactionBean details) throws BankException {
		String insqry = "Insert into transaction_details VALUES(transaction_id_seq.nextval ,?,?,?,?)";
		conn = DBUtil.getConnection();
		try {
		
		     PreparedStatement pst= conn.prepareStatement(insqry);
		     pst.setString(1,details.getTranDesc());
			 pst.setDouble(2,details.getTranAmt());
			 pst.setDate(3,Date.valueOf(details.getTrandate()));
			 pst.setString(4,details.getAccountNo());
			 int rs=pst.executeUpdate();
		   return rs;
	}
   catch(SQLException e)
		{
	   throw new BankException("Problem in fetching mobile data ");
		}
	}
}
