package com.cg.service;

import java.util.List;

import com.cg.dao.BankDaoImpl;
import com.cg.dao.IBankDao;
import com.cg.dto.AccountBean;
import com.cg.dto.TransactionBean;
import com.cg.exception.BankException;

public class BankServiceImpl implements IBankService{
    IBankDao dao=new BankDaoImpl();

	@Override
	public List<AccountBean> getAccountDetails(String cname)
			throws BankException {
		return dao.getAccountDetails(cname);
	}

	@Override
	public int addTransaction(TransactionBean details) throws BankException {
		return dao.addTransaction(details);
	}

	


}
