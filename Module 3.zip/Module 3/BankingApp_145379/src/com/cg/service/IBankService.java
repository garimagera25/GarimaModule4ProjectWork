package com.cg.service;

import java.util.List;

import com.cg.dto.AccountBean;
import com.cg.dto.TransactionBean;
import com.cg.exception.BankException;

public interface IBankService {

	public List<AccountBean> getAccountDetails(String cname) throws BankException;
	public int addTransaction(TransactionBean details) throws BankException;
}
