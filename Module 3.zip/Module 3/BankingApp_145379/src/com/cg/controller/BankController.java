package com.cg.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.AccountBean;
import com.cg.dto.TransactionBean;
import com.cg.exception.BankException;
import com.cg.service.BankServiceImpl;
import com.cg.service.IBankService;

@WebServlet(urlPatterns={"/getAccounts","/debit","/transaction"})
public class BankController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public BankController() {
        super();
        // TODO Auto-generated constructor stub
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	doPost(request,response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IBankService service=new BankServiceImpl(); 
		String target = "";
		String url=request.getServletPath();
		switch(url){
		case "/getAccounts":
			String user=request.getParameter("cname");
			HttpSession sess=request.getSession(true);
			sess.setAttribute("cname", user);
			try {
				List<AccountBean> blist = service.getAccountDetails(user);
				if(!blist.isEmpty())
				{
					System.out.println("working");
					System.out.println("alist");
				   request.setAttribute("blist", blist);
				   target="AccountInfo.jsp";
				}
				else{
					throw new BankException("Customer Name not exist");
				}
				} catch (BankException e) {
					String error = e.getMessage();
					request.setAttribute("error",error);
					target="CustomerError.jsp";
				}
				break;
				
		case "/debit":
			String accno=request.getParameter("accno");
			System.out.println(accno);
			request.setAttribute("accno", accno);
			target="DebitAmount.jsp";
			break;
			
		case "/transaction":
			double amount=Double.parseDouble(request.getParameter("amount"));
		    String accno1=request.getParameter("accNo");
		    TransactionBean details=new TransactionBean();
		    details.setTranDesc("ATM Debit");
		    details.setAccountNo(accno1);
		    details.setTranAmt(amount);
		    details.setTrandate(LocalDate.now());
		    try
		    {
		    	int rst=service.addTransaction(details);
			   request.setAttribute("details", details);
			  target="TransactionSuccess.jsp";
		    } catch (BankException e) {
				 request.setAttribute("error", e.getMessage());
				 target="Error.jsp";
			 }
			 break;		 
		}//end of switch
		RequestDispatcher disp = request.getRequestDispatcher(target);
	    disp.forward(request,response);
	}
}
