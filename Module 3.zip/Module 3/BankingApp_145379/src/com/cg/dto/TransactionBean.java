package com.cg.dto;

import java.sql.Date;
import java.time.LocalDate;

public class TransactionBean {

	private int tranId;
	private String tranDesc;
	private double tranAmt;
	private LocalDate trandate;
	private String accountNo;
	private String accountDetails;
	public int getTranId() {
		return tranId;
	}
	public void setTranId(int tranId) {
		this.tranId = tranId;
	}
	public String getTranDesc() {
		return tranDesc;
	}
	public void setTranDesc(String tranDesc) {
		this.tranDesc = tranDesc;
	}
	public double getTranAmt() {
		return tranAmt;
	}
	public void setTranAmt(double tranAmt) {
		this.tranAmt = tranAmt;
	}
	public LocalDate getTrandate() {
		return trandate;
	}
	public void setTrandate(LocalDate trandate) {
		this.trandate = trandate;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountDetails() {
		return accountDetails;
	}
	public void setAccountDetails(String accountDetails) {
		this.accountDetails = accountDetails;
	}
	
	
}
