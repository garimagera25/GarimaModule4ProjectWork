package com.cg.dao;

public class ProductDaoImpl implements IProductDao {

}
