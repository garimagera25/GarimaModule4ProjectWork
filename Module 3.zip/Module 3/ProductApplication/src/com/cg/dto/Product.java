package com.cg.dto;

public class Product {

}
