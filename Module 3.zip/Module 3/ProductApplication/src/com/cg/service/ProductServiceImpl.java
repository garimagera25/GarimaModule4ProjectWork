package com.cg.service;

import com.cg.dao.IProductDao;
import com.cg.dao.ProductDaoImpl;

public class ProductServiceImpl implements IProductService{
IProductDao dao=new ProductDaoImpl();
}
