package com.cg.spring.anno.bean;

import org.springframework.stereotype.Component;

@Component("dept")
public class Department {

	private String deptName;
	private int deptid;
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public int getDeptid() {
		return deptid;
	}
	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}
	@Override
	public String toString() {
		return "Department [deptName=" + deptName + ", deptid=" + deptid + "]";
	}
	
	
}
