
package com.cg.demothreejpa.service;

import java.util.List;

import com.cg.demothreejpa.dto.Project;
import com.cg.demothreejpa.dao.IProjectDao;
import com.cg.demothreejpa.dao.ProjectDaoImpl;

public class ProjectServiceImpl implements IProjectService{

	IProjectDao projectDao=new ProjectDaoImpl();
	
	@Override
	public int addProject(Project proj) {
		return projectDao.addProject(proj);
	}

	@Override
	public void removeProject(int projId) {
		projectDao.removeProject(projId);
		
	}

	@Override
	public Project findProject(int projId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Project> showAllProject() {
		return projectDao.showAllProject();
	}

	@Override
	public void updateProject(Project pro) {
		projectDao.updateProject(pro);
	}

}
