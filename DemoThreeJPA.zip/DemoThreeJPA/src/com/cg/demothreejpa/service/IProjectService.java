package com.cg.demothreejpa.service;

import java.util.List;

import com.cg.demothreejpa.dto.Project;

public interface IProjectService {

	public int addProject(Project proj);
	public void removeProject(int projId);
	public Project findProject(int projId);
	public List<Project> showAllProject();
	public void updateProject(Project pro);
}
