package com.cg.demothreejpa.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.demothreejpa.dao.ProjectUtil;
import com.cg.demothreejpa.dto.Project;

public class ProjectDaoImpl implements IProjectDao {

EntityManager em;
	
	public  ProjectDaoImpl() {
		em=ProjectUtil.getEntityManager();
	}
	@Override
	public int addProject(Project proj) {
		em.getTransaction().begin();
		em.persist(proj);
		em.getTransaction().commit();
		return proj.getProjectId();
	}
	
	@Override
	public void removeProject(int projId) {
		em.getTransaction().begin();
		Query queryRemove=em.createQuery("DELETE FROM Project WHERE projectId=:pid");
		queryRemove.setParameter("pid", projId);
		queryRemove.executeUpdate();
		em.getTransaction().commit();
		
	}
	@Override
	public Project findProject(int projId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public List<Project> showAllProject() {
	//	Query queryOne=em.createQuery("FROM Project"); //other method is 
		//TypedQuery<Project> queryOne=em.createQuery("FROM Project",Project.class);
		Query queryOne=em.createNamedQuery("getALLData");
		List<Project> myList=queryOne.getResultList();
		return myList;
	}
	
	@Override
	public void updateProject(Project pro) {
		em.getTransaction().begin();
		Query queryUpdate=em.createQuery("UPDATE Project SET projectName=:pname,projectDepartment=:pdep where projectId=:pid");
		queryUpdate.setParameter("pid", pro.getProjectId());
		queryUpdate.setParameter("pname",pro.getProjectName());
		queryUpdate.setParameter("pdep",pro.getProjectDepartment());
		queryUpdate.executeUpdate();
		em.getTransaction().commit();
		
		
	}
	
	}
