package com.cg.demotwojpa.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.demothreejpa.dto.Project;
import com.cg.demothreejpa.service.IProjectService;
import com.cg.demothreejpa.service.ProjectServiceImpl;

public class MyTest {

public static void main(String[] args) {
		
		IProjectService projectService=new ProjectServiceImpl();
		int choice;
		Scanner scrOne=new Scanner(System.in);
		System.out.println("1.Show ALL 2.ADD 3.DELETE 4.UPDATE 5.SERACH");
		System.out.println("Enter Choice");
		choice=scrOne.nextInt();
		switch(choice){
		case 1: List<Project> allData=projectService.showAllProject();
		for(Project project : allData) 
		{
			System.out.println("ID is "+project.getProjectId());
			System.out.println("Name is "+project.getProjectName());
			System.out.println("Department is "+project.getProjectDepartment());
		}
			break;
			
			//Add
			case 2:
			Project pro=new Project();
			Scanner scr=new Scanner(System.in);
			System.out.println("Enter Project Name ");
			String pname=scr.next();
			System.out.println("Enter Project Department Name ");
			String dname=scr.next();
			pro.setProjectName(pname);
			pro.setProjectDepartment(dname);
			int id=projectService.addProject(pro);
			System.out.println("Project Id is"+id);
			break;
			
			//Delete
			case 3:
				System.out.println("Enter Project Id to delete");
				int rid=scrOne.nextInt();
				projectService.removeProject(rid);
				break;
				//Update
			case 4:
				System.out.println("Enter Project Id to update");
				int uid=scrOne.nextInt();
				System.out.println("Enter Project name to update");
				String uname=scrOne.next();
				System.out.println("Enter Project department to update");
				String udep=scrOne.next();
				
				Project pupdate=new Project();
				pupdate.setProjectId(uid);
				pupdate.setProjectName(uname);
				pupdate.setProjectDepartment(udep);
				projectService.updateProject(pupdate);
				
			
		}
	}	
		}
